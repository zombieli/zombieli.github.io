import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../web/', import.meta.url));
const prefix = '/demos/inspection-notebook/';
const types = {'.html':'text/html; charset=utf-8','.css':'text/css','.mjs':'text/javascript','.js':'text/javascript','.webmanifest':'application/manifest+json','.png':'image/png','.svg':'image/svg+xml'};
http.createServer(async (request,response) => {
  const url = new URL(request.url,'http://localhost');
  if (url.pathname === '/') { response.writeHead(200,{'Content-Type':'text/html'}); response.end('<!doctype html><title>Local demo host</title><a href="'+prefix+'">Open inspection notebook</a>'); return; }
  if (!url.pathname.startsWith(prefix)) { response.writeHead(404); response.end('Not found'); return; }
  const relative = decodeURIComponent(url.pathname.slice(prefix.length)) || 'index.html';
  const file = path.resolve(root,relative);
  if (!file.startsWith(root)) {response.writeHead(403);response.end();return;}
  try { const data = await readFile(file); response.writeHead(200,{'Content-Type':types[path.extname(file)] || 'application/octet-stream','Cache-Control':'no-cache'});response.end(data); }
  catch { response.writeHead(404);response.end('Not found'); }
}).listen(Number(process.env.PORT || 4175),'127.0.0.1',()=>console.log(`Inspection notebook: http://127.0.0.1:${process.env.PORT || 4175}${prefix}`));
