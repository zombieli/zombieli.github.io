import('../tests/browser.mjs').catch(error => { console.error(error); process.exitCode=1; });
