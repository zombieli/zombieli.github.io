import { deflateSync } from 'node:zlib';
import { writeFile } from 'node:fs/promises';
function crc32(buffer){let crc=0xffffffff;for(const byte of buffer){crc^=byte;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function chunk(type,data){const label=Buffer.from(type);const length=Buffer.alloc(4);length.writeUInt32BE(data.length);const checksum=Buffer.alloc(4);checksum.writeUInt32BE(crc32(Buffer.concat([label,data])));return Buffer.concat([length,label,data,checksum]);}
for(const size of [192,512]){
  const rows=Buffer.alloc((size*4+1)*size);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const u=x/size*512,v=y/size*512;
    let color=[19,45,60];
    if(u>112&&u<400&&v>80&&v<432)color=[245,243,236];
    if(u>176&&u<336&&v>58&&v<118)color=[105,195,169];
    if((u>157&&u<224&&Math.abs(v-(u+75))<15)||(u>=213&&u<355&&Math.abs(v-(517-u))<15))color=[14,116,109];
    if((v>341&&v<355&&u>170&&u<343)||(v>377&&v<391&&u>170&&u<288))color=[169,186,177];
    const offset=y*(size*4+1)+1+x*4;rows.set([...color,255],offset);
  }
  const header=Buffer.alloc(13);header.writeUInt32BE(size,0);header.writeUInt32BE(size,4);header[8]=8;header[9]=6;
  await writeFile(new URL(`../web/icons/icon-${size}.png`,import.meta.url),Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(rows)),chunk('IEND',Buffer.alloc(0))]));
}
