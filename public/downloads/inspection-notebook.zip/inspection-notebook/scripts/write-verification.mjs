import { readFile, writeFile, readdir } from 'node:fs/promises';
const evidence = new URL('../evidence/',import.meta.url);
const projectUrl = new URL('../',import.meta.url).href;
const projectWindows = decodeURIComponent(new URL('../',import.meta.url).pathname).replace(/^\//,'').replaceAll('/','\\');
for (const name of await readdir(evidence)) {
  if (!name.endsWith('.txt')) continue;
  const file = new URL(name,evidence);
  const output = await readFile(file,'utf8');
  const redacted = output.replaceAll(projectUrl,'[project]/').replaceAll(decodeURIComponent(projectUrl),'[project]/').replaceAll(projectWindows,'[project]\\');
  await writeFile(file,redacted);
}
const output = await readFile(new URL('domain-green.txt',evidence),'utf8');
const count = key => Number(output.match(new RegExp(`(?:ℹ|#) ${key} (\\d+)`))?.[1]);
const browser = JSON.parse(await readFile(new URL('browser-results.json',evidence),'utf8'));
if (!Number.isFinite(count('tests')) || count('fail') !== 0 || browser.error || !browser.checks.every(check=>check.passed)) throw new Error('Verification output is missing or contains failures.');
const report = {
  projectId:'inspection-notebook', version:'1.1.0', verifiedAt:new Date().toISOString(),
  nodeVersion:process.version,
  unit:{command:'node --test --test-isolation=none tests/core.test.mjs',tests:count('tests'),passed:count('pass'),failed:count('fail'),output:'domain-green.txt'},
  browser:{command:'node scripts/browser-qa.cjs',name:'Desktop Chrome',version:browser.browser,baseUrl:browser.baseUrl,checks:browser.checks.length,passed:browser.passed,failed:0,output:'browser-green.txt',details:'browser-results.json'},
  layouts:[360,390,768,1440],
  screenshots:['notebook-1440.png','notebook-390.png'],
  coverage:['Draft and submitted persistence in real IndexedDB after reload','Pending save and submit lock all editor fields against typing until the actual transaction completes','Required completion fields and immutable submitted storage writes','Atomic rollback with fresh IDs before and after a duplicate conflict','Invalid JSON-record import preserves existing database','JSON download and fresh-origin-context import round trip','Offline reload after service worker activation and page control','Status filters and keyboard activation/focus','Four viewport widths with open and closed editor','Same-clock and stale-tab draft conflict handling','Manifest scope, real PNG dimensions and unrelated host route isolation','1000-record transaction capacity and worst-case backup escape size','Actionable unavailable-storage state and no uncaught page errors'],
  limitations:['Desktop Chrome only; no physical phone, native app or install-prompt verification.','Unavailable-storage presentation intentionally disables IndexedDB; quota exhaustion and eviction not reproduced.','Origin-local data can be cleared; no server upload, multi-user sync or cryptographic sealing.','1000-record bounded notebook; no deletion workflow.','Keyboard checks cover selected paths, not a full assistive-technology audit.'],
  outputRedaction:'Local project path prefixes are replaced with [project] in captured text output.'
};
await writeFile(new URL('verification.json',evidence),JSON.stringify(report,null,2)+'\n');
console.log(`Recorded ${report.unit.passed} domain tests and ${report.browser.passed} browser checks.`);
