import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createDraft, updateDraft, submitRecord, validateRecord, parseBackup, makeBackup } from '../web/core.mjs';

const t0 = '2026-10-13T09:00:00.000Z';
const t1 = '2026-10-13T09:01:00.000Z';
const draft = () => createDraft('record-1', t0);
const complete = () => updateDraft(draft(), { assetId:'TRN-101', condition:'acceptable', checks:{isolation:true,housing:true,indicators:true}, notes:'Training only.' }, t1);
const backup = records => JSON.stringify({schemaVersion:1, exportedAt:t1, records});

test('draft begins with empty fields and explicit unchecked checklist', () => {
  assert.deepEqual(draft(), {id:'record-1',status:'draft',assetId:'',condition:'',checks:{isolation:false,housing:false,indicators:false},notes:'',createdAt:t0,updatedAt:t0,submittedAt:null});
});
test('draft editing preserves identity and original creation time', () => {
  const value = updateDraft(draft(), {notes:'Inspection started'}, t1);
  assert.equal(value.notes,'Inspection started'); assert.equal(value.createdAt,t0); assert.equal(value.updatedAt,t1);
});
test('completion requires an asset', () => { assert.throws(() => submitRecord({...complete(),assetId:''},t1), /asset/i); });
test('completion requires a condition', () => { assert.throws(() => submitRecord({...complete(),condition:''},t1), /condition/i); });
test('completion requires every checklist item', () => { assert.throws(() => submitRecord({...complete(),checks:{isolation:true,housing:false,indicators:true}},t1), /checklist/i); });
test('complete record receives a fixed submission timestamp', () => { const value = submitRecord(complete(),t1); assert.equal(value.status,'submitted'); assert.equal(value.submittedAt,t1); assert.equal(value.updatedAt,t1); });
test('submitted record cannot be edited', () => { assert.throws(() => updateDraft(submitRecord(complete(),t1),{notes:'changed'},t1), /read.only/i); });
test('submitted record cannot be resubmitted', () => { assert.throws(() => submitRecord(submitRecord(complete(),t1),t1), /read.only/i); });
test('draft update cannot change status or identity', () => { assert.throws(() => updateDraft(draft(),{status:'submitted'},t1), /field/i); });
test('draft update cannot change creation time', () => { assert.throws(() => updateDraft(draft(),{createdAt:t1},t1), /field/i); });
test('record validation rejects unknown fields', () => { assert.throws(() => validateRecord({...draft(),surprise:1}), /field/i); });
test('record validation rejects unknown equipment', () => { assert.throws(() => validateRecord({...draft(),assetId:'production-999'}), /asset/i); });
test('record validation rejects unknown condition', () => { assert.throws(() => validateRecord({...draft(),condition:'maybe'}), /condition/i); });
test('record validation requires boolean checklist values', () => { assert.throws(() => validateRecord({...draft(),checks:{isolation:'true',housing:false,indicators:false}}), /checklist/i); });
test('record validation rejects missing checklist item', () => { assert.throws(() => validateRecord({...draft(),checks:{isolation:false,housing:false}}), /checklist/i); });
test('notes have a bounded length', () => { assert.throws(() => updateDraft(draft(),{notes:'x'.repeat(2001)},t1), /2000/); });
test('timestamps must be canonical ISO strings', () => { assert.throws(() => validateRecord({...draft(),createdAt:'yesterday'}), /timestamp/i); });
test('updated timestamp cannot precede creation', () => { assert.throws(() => validateRecord({...draft(),updatedAt:'2026-10-12T09:00:00.000Z'}), /timestamp/i); });
test('draft cannot include a submission timestamp', () => { assert.throws(() => validateRecord({...draft(),submittedAt:t1}), /submission/i); });
test('submitted imports cannot evade completion rules', () => { assert.throws(() => validateRecord({...draft(),status:'submitted',submittedAt:t0}), /asset/i); });
test('IDs reject unsafe or empty identities', () => { for(const id of ['', '../record', '<script>']) assert.throws(() => createDraft(id,t0), /identity/i); });
test('backup round trip preserves records without mutation', () => { const records = [draft(), submitRecord({...complete(),id:'record-2'},t1)]; assert.deepEqual(parseBackup(JSON.stringify(makeBackup(records,t1))),records); });
test('backup rejects duplicate IDs within the file', () => { assert.throws(() => parseBackup(backup([draft(),draft()])), /duplicate/i); });
test('backup rejects existing IDs even when content is identical', () => { assert.throws(() => parseBackup(backup([draft()]),new Set(['record-1'])), /already exists/i); });
test('backup validates every record before returning any', () => { assert.throws(() => parseBackup(backup([draft(),{...draft(),id:'record-2',notes:42}])), /notes/i); });
test('backup rejects unknown schema versions', () => { assert.throws(() => parseBackup(JSON.stringify({schemaVersion:2,exportedAt:t1,records:[]})), /version/i); });
test('backup rejects unexpected top-level fields', () => { assert.throws(() => parseBackup(JSON.stringify({schemaVersion:1,exportedAt:t1,records:[],deleteAll:true})), /field/i); });
test('backup rejects malformed JSON', () => { assert.throws(() => parseBackup('{'), /JSON/i); });
test('backup rejects excessive record count', () => { assert.throws(() => parseBackup(backup(Array.from({length:1001},(_,i)=>({...draft(),id:`record-${i}`})))), /1000/); });
test('backup rejects oversized input before parsing', () => { assert.throws(() => parseBackup(' '.repeat(16_000_001)), /16 MB/); });
test('validation returns an independent copy', () => { const source = draft(); const validated = validateRecord(source); validated.checks.housing=true; assert.equal(source.checks.housing,false); });
test('condition must be a string rather than an array coerced to a known key', () => { assert.throws(() => validateRecord({...draft(),condition:['acceptable']}), /condition/i); });
test('same-clock draft writes still receive distinct conflict timestamps', () => { const first=updateDraft(draft(),{notes:'First'},t0);const second=updateDraft(first,{notes:'Second'},t0);assert.ok(first.updatedAt>t0);assert.ok(second.updatedAt>first.updatedAt); });
test('a maximum-size notebook with multibyte notes can export and import its backup',()=>{
  const records=Array.from({length:1000},(_,i)=>({...draft(),id:`unicode-${i}`,notes:'\u2014'.repeat(2000)}));
  assert.equal(parseBackup(JSON.stringify(makeBackup(records,t1),null,2)).length,1000);
});
test('a maximum-size notebook with escaped control characters can round trip its backup',()=>{
  const records=Array.from({length:1000},(_,i)=>({...draft(),id:`escaped-${i}`,notes:'\u0000'.repeat(2000)}));
  assert.equal(parseBackup(JSON.stringify(makeBackup(records,t1),null,2)).length,1000);
});
