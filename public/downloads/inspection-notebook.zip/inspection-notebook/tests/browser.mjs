import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';
import path from 'node:path';
const project = path.resolve(import.meta.dirname,'..');
const evidence = path.join(project,'evidence');
const base = process.env.BASE_URL || 'http://127.0.0.1:4175/demos/inspection-notebook/';
const modulePath = process.env.PLAYWRIGHT_MODULE;
const { chromium } = await (modulePath ? import(pathToFileURL(modulePath.endsWith('.mjs') ? modulePath : path.join(modulePath,'index.mjs')).href) : import('playwright'));
await mkdir(evidence,{recursive:true});
const results = [];
let server;
let browser;
async function check(name, callback) { await callback(); results.push({name,passed:true}); console.log(`PASS ${name}`); }
async function pendingEditorAction(page, buttonName, expectedNotice) {
  const expectedNotes=await page.getByLabel('Inspection notes').inputValue();
  await page.evaluate(async()=>{
    const {openStorage}=await import('./storage.mjs');
    const database=await openStorage();
    const transaction=database.transaction('records','readwrite');
    let released=false;
    window.releaseInspectionWrite=()=>{released=true;};
    const keepAlive=()=>{
      const request=transaction.objectStore('records').get('pending-write-probe');
      request.onsuccess=()=>{if(!released)keepAlive();};
    };
    keepAlive();
  });
  try {
    await page.getByRole('button',{name:buttonName,exact:true}).click();
    assert.equal(await page.locator('#inspection-form input,#inspection-form select,#inspection-form textarea').evaluateAll(nodes=>nodes.every(node=>node.matches(':disabled'))),true,'Every editable field must be disabled while the transaction is pending');
    assert.equal(await page.getByRole('button',{name:'Close inspection',exact:true}).isDisabled(),true,'Editor context must remain fixed during persistence');
    await page.getByLabel('Inspection notes').evaluate(node=>node.focus());
    await page.keyboard.type(' Later input');
    assert.equal(await page.getByLabel('Inspection notes').inputValue(),expectedNotes,'Keyboard input cannot change a pending snapshot');
  } finally { await page.evaluate(()=>{window.releaseInspectionWrite();delete window.releaseInspectionWrite;}); }
  await page.getByRole('status').filter({hasText:expectedNotice}).waitFor();
  assert.equal(await page.getByLabel('Inspection notes').inputValue(),expectedNotes);
  const stored=await page.evaluate(async()=>{const {listRecords}=await import('./storage.mjs');return (await listRecords())[0].notes;});
  assert.equal(stored,expectedNotes);
}
try {
  if (!process.env.BASE_URL) {
    server = spawn(process.execPath,['scripts/serve.mjs'],{cwd:project,env:{...process.env,PORT:'4175'},stdio:'pipe'});
    await new Promise((resolve,reject)=>{server.stdout.once('data',resolve);server.once('error',reject);server.once('exit',code=>reject(new Error(`Server exited ${code}`)));});
  }
  browser = await chromium.launch({...process.env.CHROMIUM_PATH ? {executablePath:process.env.CHROMIUM_PATH} : {channel:'chrome'},headless:true});
  const context = await browser.newContext({acceptDownloads:true});
  const page = await context.newPage();
  const pageErrors=[]; page.on('pageerror',error=>pageErrors.push(error.message));
  await page.goto(base);
  await check('empty state and explicit sample action',async()=>{
    await page.getByText('No inspections yet',{exact:true}).waitFor();
    assert.equal(await page.locator('.record-card').count(),0);
  });
  await check('service worker ready and controlled within demo directory',async()=>{
    const scope = await page.evaluate(async()=>{const registration=await navigator.serviceWorker.ready;return registration.scope;});
    assert.equal(scope,new URL('.',base).href);
    await page.waitForFunction(()=>Boolean(navigator.serviceWorker.controller));
  });
  await page.getByRole('button',{name:'New inspection',exact:true}).click();
  await check('submission blocks missing required fields',async()=>{
    await page.getByRole('button',{name:'Submit inspection',exact:true}).click();
    await page.getByRole('alert').filter({hasText:/asset/i}).waitFor();
    assert.equal(await page.locator('.record-card').count(),1);
  });
  await page.getByLabel('Fictional equipment asset').selectOption('TRN-101');
  await page.getByLabel('Needs attention',{exact:true}).check();
  await page.getByLabel('Isolation point identified').check();
  await page.getByLabel('Housing and cable entries checked').check();
  await page.getByLabel('Labels and indicators checked').check();
  await page.getByLabel('Inspection notes').fill('Training review: <img src=x onerror="window.bad=true">');
  await check('pending draft save locks all editable fields until IndexedDB completes',async()=>{
    await pendingEditorAction(page,'Save draft','Draft saved');
    assert.equal(await page.getByLabel('Inspection notes').isDisabled(),false,'A saved draft becomes editable again');
  });
  await check('IndexedDB draft persists after reload',async()=>{
    await page.reload();
    await page.locator('.record-card button').first().click();
    assert.equal(await page.getByLabel('Inspection notes').inputValue(),'Training review: <img src=x onerror="window.bad=true">');
    assert.equal(await page.getByLabel('Fictional equipment asset').inputValue(),'TRN-101');
  });
  await check('pending submission locks fields and keeps the finished record read-only',async()=>{
    await pendingEditorAction(page,'Submit inspection','Inspection submitted');
    assert.equal(await page.getByLabel('Inspection notes').isDisabled(),true,'Submitted fields remain read-only after completion');
  });
  await check('submitted record is read-only after reload',async()=>{
    await page.getByRole('status').filter({hasText:'Inspection submitted'}).waitFor();
    await page.reload(); await page.locator('.record-card button').first().click();
    assert.equal(await page.getByRole('button',{name:'Save draft',exact:true}).count(),0);
    assert.equal(await page.getByLabel('Inspection notes').isDisabled(),true);
    assert.equal(await page.evaluate(()=>window.bad),undefined);
    const error=await page.evaluate(async()=>{const s=await import('./storage.mjs');const records=await s.listRecords();try{await s.saveRecord({...records[0],notes:'modified'},records[0].updatedAt);return '';}catch(e){return e.message;}});
    assert.match(error,/read.only/i);
  });
  await check('real IndexedDB transaction rolls back an earlier insertion on duplicate conflict',async()=>{
    const result=await page.evaluate(async()=>{
      const s=await import('./storage.mjs');const c=await import('./core.mjs');
      const before=await s.listRecords();const fresh=c.createDraft('rollback-probe',new Date().toISOString());
      const later=c.createDraft('rollback-later',new Date().toISOString());
      let error='';try{await s.importRecords([fresh,before[0],later]);}catch(e){error=e.message;}
      const after=await s.listRecords();return {error,before:before.length,after:after.length,contains:after.some(r=>['rollback-probe','rollback-later'].includes(r.id))};
    });
    assert.match(result.error,/already exists/i); assert.equal(result.after,result.before);assert.equal(result.contains,false);
  });
  await check('invalid JSON import leaves persisted database unchanged',async()=>{
    const before=await page.locator('.record-card').count();
    await page.getByLabel('Import JSON backup').setInputFiles({name:'invalid.json',mimeType:'application/json',buffer:Buffer.from('{"schemaVersion":1,"exportedAt":"2026-10-13T09:00:00.000Z","records":[{"id":"broken"}]}')});
    await page.getByRole('alert').filter({hasText:/field/i}).waitFor();
    assert.equal(await page.locator('.record-card').count(),before);
  });
  let exported;
  await check('export download and fresh-database import round trip',async()=>{
    const event=page.waitForEvent('download');await page.getByRole('button',{name:'Export JSON',exact:true}).click();
    const download=await event;exported=await readFile(await download.path());
    assert.equal(JSON.parse(exported).records.length,1);
    const other=await browser.newContext();const target=await other.newPage();await target.goto(base);
    await target.getByText('No inspections yet',{exact:true}).waitFor();
    await target.getByLabel('Import JSON backup').setInputFiles({name:'roundtrip.json',mimeType:'application/json',buffer:exported});
    await target.getByRole('status').filter({hasText:'Imported 1 record'}).waitFor();assert.equal(await target.locator('.record-card').count(),1);
    await target.getByLabel('Import JSON backup').setInputFiles({name:'duplicate.json',mimeType:'application/json',buffer:exported});
    await target.getByRole('alert').filter({hasText:/already exists/i}).waitFor();assert.equal(await target.locator('.record-card').count(),1);
    await other.close();
  });
  await check('offline reload retains app and completed record',async()=>{
    await context.setOffline(true);await page.reload();
    await page.getByText('Offline · saved on this device',{exact:true}).waitFor();
    assert.equal(await page.locator('.record-card').count(),1);
    await page.locator('.record-card button').first().click();assert.equal(await page.getByLabel('Inspection notes').isDisabled(),true);
    await context.setOffline(false);
  });
  await page.getByRole('button',{name:'Close inspection',exact:true}).click();
  await page.getByRole('button',{name:'Load fictional examples',exact:true}).click();
  await page.getByRole('status').filter({hasText:'Added 2 fictional examples'}).waitFor();
  await check('status filtering exposes the matching subset',async()=>{
    await page.getByRole('button',{name:'Drafts',exact:true}).click();assert.equal(await page.locator('.record-card').count(),1);
    await page.getByRole('button',{name:'Submitted',exact:true}).click();assert.equal(await page.locator('.record-card').count(),2);
    await page.getByRole('button',{name:'All inspections',exact:true}).click();assert.equal(await page.locator('.record-card').count(),3);
  });
  await check('responsive layouts at 360, 390, 768 and 1440 pixels',async()=>{
    for(const width of [360,390,768,1440]){
      await page.setViewportSize({width,height:900});
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`overflow at ${width}`);
      await page.locator('.record-card button').first().click();
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`editor overflow at ${width}`);
      await page.getByRole('button',{name:'Close inspection',exact:true}).click();
      if(width===390 || width===1440)await page.screenshot({path:path.join(evidence,`notebook-${width}.png`),fullPage:true});
    }
  });
  await check('keyboard reaches creation and editor fields',async()=>{
    await page.getByRole('button',{name:'New inspection',exact:true}).focus();await page.keyboard.press('Enter');
    await page.getByLabel('Fictional equipment asset').waitFor();
    await page.waitForFunction(()=>!document.getElementById('asset').disabled);
    assert.equal(await page.evaluate(()=>document.activeElement.id),'asset','Creation focuses the first editable field after the pending lock is released');
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(()=>document.activeElement.id),'condition-acceptable');
    await page.getByRole('button',{name:'Close inspection',exact:true}).click();
  });
  await check('concurrent draft edit conflicts preserve the first save',async()=>{
    const result=await page.evaluate(async()=>{const s=await import('./storage.mjs');const c=await import('./core.mjs');const d=(await s.listRecords()).find(r=>r.status==='draft');const first=c.updateDraft(d,{notes:'First writer'},new Date().toISOString());await s.saveRecord(first,d.updatedAt);let error='';try{await s.saveRecord(c.updateDraft(d,{notes:'Stale writer'},new Date().toISOString()),d.updatedAt);}catch(e){error=e.message;}return {error,note:(await s.listRecords()).find(r=>r.id===d.id).notes};});
    assert.match(result.error,/another tab/i);assert.equal(result.note,'First writer');
  });
  await check('manifest has relative install scope and real PNG icon sizes',async()=>{
    const manifest=await page.evaluate(async()=>await (await fetch('./manifest.webmanifest')).json());
    assert.equal(manifest.scope,'./');assert.equal(manifest.start_url,'./');
    for(const icon of manifest.icons){const dimensions=await page.evaluate(async src=>{const image=new Image();image.src=src;await image.decode();return `${image.naturalWidth}x${image.naturalHeight}`;},icon.src);assert.equal(dimensions,icon.sizes);}
  });
  await check('notebook capacity rejects an extra record without partial writes',async()=>{
    const separate=await browser.newContext();const target=await separate.newPage();await target.goto(base);await target.getByText('No inspections yet',{exact:true}).waitFor();
    const result=await target.evaluate(async()=>{const s=await import('./storage.mjs');const c=await import('./core.mjs');const now=new Date().toISOString();await s.importRecords(Array.from({length:1000},(_,i)=>c.createDraft(`capacity-${i}`,now)));let error='';try{await s.importRecords([c.createDraft('one-too-many',now)]);}catch(e){error=e.message;}return {error,count:(await s.listRecords()).length};});
    assert.match(result.error,/1000/);assert.equal(result.count,1000);await separate.close();
  });
  await check('unrelated host route is outside notebook control',async()=>{
    await page.goto(new URL('/',base).href);
    const scope=await page.evaluate(()=>navigator.serviceWorker.controller?.scriptURL || null);
    assert.equal(scope?.includes('/inspection-notebook/sw.js')||false,false);
  });
  await check('unavailable storage gives an actionable error',async()=>{
    const failed=await browser.newContext();await failed.addInitScript(()=>Object.defineProperty(window,'indexedDB',{value:undefined}));
    const target=await failed.newPage();await target.goto(base);await target.getByRole('alert').filter({hasText:/storage.*unavailable/i}).waitFor();
    assert.equal(await target.getByRole('button',{name:'New inspection',exact:true}).isDisabled(),true);await failed.close();
  });
  await check('no uncaught page errors',async()=>assert.deepEqual(pageErrors,[]));
  await writeFile(path.join(evidence,'browser-results.json'),JSON.stringify({baseUrl:base,browser:await browser.version(),date:new Date().toISOString(),checks:results,passed:results.length,limitations:['Desktop Chrome automation; no native phone or installation prompt test.','Storage-unavailable state uses a deliberately disabled IndexedDB API.']},null,2)+'\n');
} catch(error) {
  await writeFile(path.join(evidence,'browser-results.json'),JSON.stringify({baseUrl:base,checks:results,error:error.stack,passed:results.length},null,2)+'\n');
  throw error;
} finally { await browser?.close();server?.kill(); }
