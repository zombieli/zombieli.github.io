# Field Service Workflow

A portfolio application for a fictional workshop. Report a fault on a synthetic device, assign a technician label, record a resolution and inspect the status history. It uses synthetic records and no employer code.

## Local API and database

Python 3.12 is the tested version. From this directory:

```sh
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8001
```

SQLite is created under `data/`. Set `WORKFLOW_DB` to another file path for an independent database; do not delete existing records to reset a demo. API documentation: http://127.0.0.1:8001/docs.

In a second terminal, install the frontend dependencies with Node 24:

```sh
cd frontend
npm ci
```

PowerShell API mode:

```powershell
$env:VITE_SERVICE_MODE = 'api'
npm run dev
```

On macOS/Linux: `VITE_SERVICE_MODE=api npm run dev`. Open http://127.0.0.1:5174/field-service-workflow/. The development server proxies `/api` to the local API. Vite's API mode is for local development; the public Pages build uses the browser demo service.

## Static demo

Start a fresh terminal with `VITE_SERVICE_MODE` unset, then:

```sh
cd frontend
npm run build
npm run preview
```

Open http://127.0.0.1:4174/field-service-workflow/. The demo is session-only, contains synthetic data and can be reset. It does not call the API or persist records. A reload resets the tab's records.

## Verification

```sh
python -m pytest -q
cd frontend
npm test
npm run build
```

The API and demo tests cover all 25 origin/target status combinations. SQLite tests additionally verify atomic rollback, stale-version rejection, restart persistence, filters and invalid input. Browser acceptance in `qa/browser-qa.cjs` runs against both local modes; the test requires Playwright plus the two frontend servers and local API described above. Set `PLAYWRIGHT_MODULE` to an installed Playwright module when it is outside this repository. Results and screenshots go in `qa/`.

Read [the design](docs/design.md) for rules and scope. Actor labels are not authenticated users. This project is not a production field-service or personnel management system. Remote repository and Pages deployment are pending GitHub connection.
