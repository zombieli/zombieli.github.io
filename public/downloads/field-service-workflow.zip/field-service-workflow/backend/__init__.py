"""Local synthetic field service application."""
