import json
import os
import sqlite3
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Literal

from fastapi import FastAPI, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT / 'contract.json').read_text(encoding='utf-8'))
Status = Literal['Open', 'Assigned', 'In Progress', 'Resolved', 'Closed']
Priority = Literal['Low', 'Medium', 'High']
Label = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=80)]
Note = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=2000)]


class CreateOrder(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    asset_id: int = Field(gt=0)
    title: Label
    description: Note
    priority: Priority = 'Medium'
    actor_label: Label


class ChangeStatus(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    target_status: Status
    expected_version: int = Field(gt=0)
    actor_label: Label
    assignee: Label | None = None
    resolution: Note | None = None


class DomainError(Exception):
    def __init__(self, status, code, message):
        self.status, self.code, self.message = status, code, message


def now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


@contextmanager
def connection(path):
    db = sqlite3.connect(path, timeout=5)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    try:
        with db:
            yield db
    finally:
        db.close()


def initialise(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with connection(path) as db:
        version = db.execute('PRAGMA user_version').fetchone()[0]
        if version not in (0, 1):
            raise RuntimeError(f'Unsupported database schema: {version}')
        if version == 1:
            return
        db.executescript('''
            BEGIN;
            CREATE TABLE assets(id INTEGER PRIMARY KEY, display_name TEXT NOT NULL, category TEXT NOT NULL);
            CREATE TABLE work_orders(
              id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES assets(id),
              title TEXT NOT NULL, description TEXT NOT NULL, priority TEXT NOT NULL,
              status TEXT NOT NULL, assignee TEXT, resolution TEXT,
              version INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
            CREATE TABLE work_order_events(
              id INTEGER PRIMARY KEY, work_order_id INTEGER NOT NULL REFERENCES work_orders(id),
              from_status TEXT, to_status TEXT NOT NULL, actor_label TEXT NOT NULL,
              note TEXT NOT NULL, version INTEGER NOT NULL, created_at TEXT NOT NULL,
              UNIQUE(work_order_id, version));
            PRAGMA user_version=1;
        ''')
        db.executemany('INSERT INTO assets VALUES(:id,:display_name,:category)', CONTRACT['assets'])


def get_order(db, order_id):
    row = db.execute('SELECT * FROM work_orders WHERE id=?', (order_id,)).fetchone()
    if row is None:
        raise DomainError(404, 'not_found', 'Work order does not exist')
    return dict(row)


def create_app(db_path):
    @asynccontextmanager
    async def lifespan(_):
        initialise(db_path)
        yield

    app = FastAPI(title='Field Service Workflow — local demo', version='0.1.0', lifespan=lifespan)

    @app.exception_handler(DomainError)
    async def domain_error(_, exc):
        return JSONResponse(status_code=exc.status, content={'error': {'code': exc.code, 'message': exc.message}})

    @app.exception_handler(RequestValidationError)
    async def invalid_request(_, exc):
        return JSONResponse(status_code=422, content={'error': {'code': 'validation_error', 'message': 'Check field types, allowed values and text lengths'}})

    @app.get('/assets')
    def assets():
        with connection(db_path) as db:
            return [dict(row) for row in db.execute('SELECT * FROM assets ORDER BY id')]

    @app.get('/work-orders')
    def orders(status: Status | None = None, priority: Priority | None = None, asset_id: int | None = Query(default=None, gt=0)):
        filters, values = [], []
        for key, value in [('status', status), ('priority', priority), ('asset_id', asset_id)]:
            if value is not None:
                filters.append(f'{key}=?')
                values.append(value)
        where = ' WHERE ' + ' AND '.join(filters) if filters else ''
        with connection(db_path) as db:
            return [dict(row) for row in db.execute('SELECT * FROM work_orders' + where + ' ORDER BY created_at DESC, id DESC', values)]

    @app.post('/work-orders', status_code=201)
    def create(data: CreateOrder):
        timestamp = now()
        with connection(db_path) as db:
            if db.execute('SELECT id FROM assets WHERE id=?', (data.asset_id,)).fetchone() is None:
                raise DomainError(422, 'unknown_asset', 'Choose an existing demo asset')
            cursor = db.execute('''INSERT INTO work_orders(asset_id,title,description,priority,status,version,created_at,updated_at)
                VALUES(?,?,?,?, 'Open',1,?,?)''', (data.asset_id, data.title, data.description, data.priority, timestamp, timestamp))
            order_id = cursor.lastrowid
            db.execute('''INSERT INTO work_order_events(work_order_id,from_status,to_status,actor_label,note,version,created_at)
                VALUES(?,NULL,'Open',?,'Created',1,?)''', (order_id, data.actor_label, timestamp))
            return get_order(db, order_id)

    @app.get('/work-orders/{order_id}')
    def detail(order_id: int):
        with connection(db_path) as db:
            return get_order(db, order_id)

    @app.get('/work-orders/{order_id}/events')
    def events(order_id: int):
        with connection(db_path) as db:
            get_order(db, order_id)
            return [dict(row) for row in db.execute('SELECT * FROM work_order_events WHERE work_order_id=? ORDER BY version', (order_id,))]

    @app.patch('/work-orders/{order_id}/status')
    def change(order_id: int, data: ChangeStatus):
        with connection(db_path) as db:
            db.execute('BEGIN IMMEDIATE')
            old = get_order(db, order_id)
            if old['version'] != data.expected_version:
                raise DomainError(409, 'version_conflict', 'This record changed. Reload it before retrying')
            target = data.target_status
            if target not in CONTRACT['transitions'][old['status']]:
                raise DomainError(409, 'invalid_transition', 'This status change is not allowed')
            if target == 'Assigned' and not data.assignee:
                raise DomainError(422, 'assignee_required', 'Assignment needs an assignee')
            if target == 'Resolved' and not data.resolution:
                raise DomainError(422, 'resolution_required', 'Resolution needs a treatment note')
            if data.assignee is not None and target != 'Assigned' or data.resolution is not None and target != 'Resolved':
                raise DomainError(422, 'unexpected_field', 'These fields do not belong to the selected transition')
            assignee = None if target == 'Open' else data.assignee if target == 'Assigned' else old['assignee']
            resolution = None if target == 'Open' else data.resolution if target == 'Resolved' else old['resolution']
            note = data.resolution or (f'Assigned to {data.assignee}' if target == 'Assigned' else 'Reopened' if target == 'Open' else target)
            timestamp, version = now(), old['version'] + 1
            db.execute('UPDATE work_orders SET status=?,assignee=?,resolution=?,version=?,updated_at=? WHERE id=?',
                       (target, assignee, resolution, version, timestamp, order_id))
            db.execute('''INSERT INTO work_order_events(work_order_id,from_status,to_status,actor_label,note,version,created_at)
                VALUES(?,?,?,?,?,?,?)''', (order_id, old['status'], target, data.actor_label, note, version, timestamp))
            return get_order(db, order_id)

    return app


app = create_app(os.environ.get('WORKFLOW_DB', str(ROOT / 'data' / 'workflow.sqlite3')))
