import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig({plugins:[vue()],base:'/field-service-workflow/',server:{proxy:{'/api':{target:'http://127.0.0.1:8001',rewrite:path=>path.replace(/^\/api/,'')}}}})
