import contract from '../../contract.json'
export {contract}
export type Order = {id:number;asset_id:number;title:string;description:string;priority:string;status:string;assignee:string|null;resolution:string|null;version:number;created_at:string;updated_at:string}
export type Event = {id:number;work_order_id:number;from_status:string|null;to_status:string;actor_label:string;note:string;version:number;created_at:string}
export type Create = {asset_id:number;title:string;description:string;priority:string;actor_label:string}
export type Change = {target_status:string;expected_version:number;actor_label:string;assignee?:string;resolution?:string}
export type Filters = {status?:string;priority?:string;asset_id?:string}
export interface Service {list(filters:Filters):Promise<Order[]>;create(data:Create):Promise<Order>;detail(id:number):Promise<Order>;events(id:number):Promise<Event[]>;change(id:number,data:Change):Promise<Order>}
export class ServiceError extends Error {constructor(public code:string,message:string){super(message)}}
export const transitions = contract.transitions as Record<string,string[]>
const fail=(code:string,message:string):never=>{throw new ServiceError(code,message)}
const text=(value:unknown,max:number)=>{if(typeof value!=='string'||!value.trim()||value.trim().length>max)fail('validation_error',`Enter text between 1 and ${max} characters`);return (value as string).trim()}
export type State={schema_version:1;orders:Order[];events:Event[]}
export const emptyState=():State=>({schema_version:1,orders:[],events:[]})

/** Demo transitions use the same contract as the Python API. Storage is optional. */
export class DemoService implements Service {
  private state:State
  constructor(initial:State=emptyState(),private persist:(state:State)=>void=()=>{}){this.state=structuredClone(initial)}
  private write(next:State){this.persist(next);this.state=next}
  async reset(){this.write(emptyState())}
  async list(filters:Filters){return structuredClone(this.state.orders.filter(o=>(!filters.status||o.status===filters.status)&&(!filters.priority||o.priority===filters.priority)&&(!filters.asset_id||o.asset_id===Number(filters.asset_id))).sort((a,b)=>b.id-a.id))}
  async detail(id:number){return structuredClone(this.state.orders.find(o=>o.id===id)??fail('not_found','Work order does not exist'))}
  async events(id:number){await this.detail(id);return structuredClone(this.state.events.filter(e=>e.work_order_id===id))}
  async create(input:Create){
    if(!contract.assets.some(a=>a.id===input.asset_id))fail('unknown_asset','Choose an existing demo asset')
    if(!contract.priorities.includes(input.priority))fail('validation_error','Choose a valid priority')
    const data={...input,title:text(input.title,80),description:text(input.description,2000),actor_label:text(input.actor_label,80)}
    const id=Math.max(0,...this.state.orders.map(o=>o.id))+1, timestamp=new Date().toISOString()
    const order:Order={id,asset_id:data.asset_id,title:data.title,description:data.description,priority:data.priority,status:'Open',assignee:null,resolution:null,version:1,created_at:timestamp,updated_at:timestamp}
    const next=structuredClone(this.state)
    next.orders.push(order)
    next.events.push({id:next.events.length+1,work_order_id:id,from_status:null,to_status:'Open',actor_label:data.actor_label,note:'Created',version:1,created_at:timestamp})
    this.write(next);return structuredClone(order)
  }
  async change(id:number,data:Change){
    const old=await this.detail(id), actor=text(data.actor_label,80), target=data.target_status
    if(old.version!==data.expected_version)fail('version_conflict','This record changed. Reload it before retrying')
    if(!transitions[old.status]?.includes(target))fail('invalid_transition','This status change is not allowed')
    if(target==='Assigned'&&data.assignee===undefined)fail('assignee_required','Assignment needs an assignee')
    if(target==='Resolved'&&data.resolution===undefined)fail('resolution_required','Resolution needs a treatment note')
    if(data.assignee!==undefined&&target!=='Assigned'||data.resolution!==undefined&&target!=='Resolved')fail('unexpected_field','These fields do not belong to the selected transition')
    const assignee=target==='Open'?null:target==='Assigned'?text(data.assignee,80):old.assignee
    const resolution=target==='Open'?null:target==='Resolved'?text(data.resolution,2000):old.resolution
    const timestamp=new Date().toISOString()
    const order={...old,status:target,assignee,resolution,version:old.version+1,updated_at:timestamp}
    const next=structuredClone(this.state)
    next.orders[next.orders.findIndex(o=>o.id===id)]=order
    next.events.push({id:next.events.length+1,work_order_id:id,from_status:old.status,to_status:target,actor_label:actor,note:target==='Resolved'?resolution!:target==='Assigned'?`Assigned to ${assignee}`:target==='Open'?'Reopened':target,version:order.version,created_at:timestamp})
    this.write(next);return structuredClone(order)
  }
}

export class ApiService implements Service {
  private async request<T>(path:string,method='GET',data?:unknown):Promise<T>{
    let response:Response
    try{response=await fetch('/api'+path,{method,headers:{'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})})}catch{throw new ServiceError('unavailable','Cannot reach the local API. Your input has been kept.')}
    const body=await response.json().catch(()=>null)
    if(!response.ok)throw new ServiceError(body?.error?.code||'service_error',body?.error?.message||'The service could not save this change. Your input has been kept.')
    return body as T
  }
  list(filters:Filters){const params=new URLSearchParams(Object.entries(filters).filter((entry):entry is [string,string]=>Boolean(entry[1])));return this.request<Order[]>('/work-orders?'+params)}
  create(data:Create){return this.request<Order>('/work-orders','POST',data)}
  detail(id:number){return this.request<Order>(`/work-orders/${id}`)}
  events(id:number){return this.request<Event[]>(`/work-orders/${id}/events`)}
  change(id:number,data:Change){return this.request<Order>(`/work-orders/${id}/status`,'PATCH',data)}
}
