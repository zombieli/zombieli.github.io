import {describe,it,expect} from 'vitest'
import {DemoService,contract,emptyState,transitions} from './service'
const input={asset_id:1,title:'Synthetic fault',description:'Test record',priority:'Medium',actor_label:'Demo actor'}
describe('demo state contract',()=>{
  for(const origin of contract.statuses) for(const target of contract.statuses) it(`${origin} to ${target}`,async()=>{
    const initial=emptyState();initial.orders=[{...input,id:1,status:origin,assignee:'Demo Alex',resolution:'Earlier note',version:1,created_at:'2026-10-08T00:00:00Z',updated_at:'2026-10-08T00:00:00Z'}]
    const service=new DemoService(initial)
    const change=service.change(1,{target_status:target,expected_version:1,actor_label:'Demo',...(target==='Assigned'?{assignee:'Demo Alex'}:{}),...(target==='Resolved'?{resolution:'Fixed'}:{})})
    if(transitions[origin].includes(target))expect((await change).status).toBe(target)
    else await expect(change).rejects.toMatchObject({code:'invalid_transition'})
  })
  it('keeps state intact when persistence fails',async()=>{
    const service=new DemoService(emptyState(),()=>{throw new Error('Storage unavailable')})
    await expect(service.create(input)).rejects.toThrow('Storage unavailable')
    expect(await service.list({})).toEqual([])
  })
  it('rejects stale versions and missing treatment notes',async()=>{
    const service=new DemoService();let order=await service.create(input)
    order=await service.change(order.id,{target_status:'Assigned',expected_version:1,actor_label:'Demo',assignee:'Alex'})
    await expect(service.change(order.id,{target_status:'In Progress',expected_version:1,actor_label:'Demo'})).rejects.toMatchObject({code:'version_conflict'})
    order=await service.change(order.id,{target_status:'In Progress',expected_version:2,actor_label:'Demo'})
    await expect(service.change(order.id,{target_status:'Resolved',expected_version:3,actor_label:'Demo',resolution:' '})).rejects.toThrow()
    expect((await service.events(order.id)).length).toBe(3)
    await service.reset();expect(await service.list({})).toEqual([])
  })
})
