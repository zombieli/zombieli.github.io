import itertools
import sqlite3

import pytest
from fastapi.testclient import TestClient

from backend.app import CONTRACT, create_app, initialise


@pytest.fixture
def service(tmp_path):
    path = tmp_path / 'test.sqlite3'
    with TestClient(create_app(path), raise_server_exceptions=False) as client:
        yield client, path


def create(client, **fields):
    return client.post('/work-orders', json={'asset_id': 1, 'title': 'Readout fault', 'description': 'Synthetic fault report', 'actor_label': 'Demo coordinator', **fields})


def change(client, order, target, **fields):
    return client.patch(f"/work-orders/{order['id']}/status", json={'target_status': target, 'expected_version': order['version'], 'actor_label': 'Demo technician', **fields})


def test_complete_workflow_and_reopen(service):
    client, _ = service
    order = create(client).json()
    assert order['status'] == 'Open'
    for target, fields in [('Assigned', {'assignee': 'Demo Alex'}), ('In Progress', {}), ('Resolved', {'resolution': 'Replaced synthetic cable'}), ('Open', {})]:
        response = change(client, order, target, **fields)
        assert response.status_code == 200
        order = response.json()
    assert order['resolution'] is None and order['assignee'] is None
    events = client.get(f"/work-orders/{order['id']}/events").json()
    assert [e['version'] for e in events] == [1,2,3,4,5]
    assert events[3]['note'] == 'Replaced synthetic cable'
    assert client.get('/work-orders?status=Closed').json() == []


@pytest.mark.parametrize('origin,target', list(itertools.product(CONTRACT['statuses'], repeat=2)))
def test_all_state_pairs(service, origin, target):
    client, path = service
    order = create(client).json()
    with sqlite3.connect(path) as db:
        db.execute("UPDATE work_orders SET status=?,assignee='Demo Alex',resolution='Earlier note' WHERE id=?", (origin, order['id']))
    fields = {'assignee': 'Demo Alex'} if target == 'Assigned' else {'resolution': 'Resolved synthetic fault'} if target == 'Resolved' else {}
    response = change(client, order, target, **fields)
    assert response.status_code == (200 if target in CONTRACT['transitions'][origin] else 409)
    events = client.get(f"/work-orders/{order['id']}/events").json()
    assert len(events) == (2 if response.status_code == 200 else 1)


@pytest.mark.parametrize('fields', [{'title':' '}, {'description':''}, {'asset_id':True}, {'asset_id':999}, {'priority':'Urgent'}, {'status':'Closed'}, {'actor_label':''}, {'title':'x'*81}])
def test_invalid_create_does_not_write(service, fields):
    client, _ = service
    assert create(client, **fields).status_code == 422
    assert client.get('/work-orders').json() == []


def test_stale_write_and_required_transition_fields(service):
    client, _ = service
    old = create(client).json()
    assert change(client, old, 'Assigned').status_code == 422
    current = change(client, old, 'Assigned', assignee='Demo Alex').json()
    assert change(client, old, 'Assigned', assignee='Demo Alex').json()['error']['code'] == 'version_conflict'
    current = change(client, current, 'In Progress').json()
    assert change(client, current, 'Resolved').status_code == 422
    assert client.get(f"/work-orders/{old['id']}").json()['version'] == 3


def test_atomic_rollback_if_audit_insert_fails(service):
    client, path = service
    order = create(client).json()
    with sqlite3.connect(path) as db:
        db.execute("CREATE TRIGGER reject_event BEFORE INSERT ON work_order_events BEGIN SELECT RAISE(ABORT, 'test failure'); END;")
    assert change(client, order, 'Assigned', assignee='Demo Alex').status_code == 500
    assert client.get(f"/work-orders/{order['id']}").json() == order
    assert len(client.get(f"/work-orders/{order['id']}/events").json()) == 1
    assert create(client).status_code == 500
    assert len(client.get('/work-orders').json()) == 1


def test_filters_missing_and_restart(service):
    client, path = service
    create(client, priority='High', asset_id=2)
    create(client, priority='Low')
    assert len(client.get('/work-orders?priority=High&asset_id=2&status=Open').json()) == 1
    assert client.get('/work-orders?status=Invalid').status_code == 422
    assert client.get('/work-orders/999').status_code == 404
    assert client.get('/work-orders/999/events').status_code == 404
    initialise(path)
    with TestClient(create_app(path)) as restarted:
        assert len(restarted.get('/work-orders').json()) == 2
        assert len(restarted.get('/assets').json()) == 3
