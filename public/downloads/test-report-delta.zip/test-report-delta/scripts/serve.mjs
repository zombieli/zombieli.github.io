import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { extname, resolve, sep } from 'node:path';
const root = fileURLToPath(new URL('../web/',import.meta.url));
const mime = {'.html':'text/html','.css':'text/css','.mjs':'text/javascript','.json':'application/json'};
createServer(async (req,res) => {
  try {
    const path = resolve(root, '.' + decodeURIComponent(new URL(req.url,'http://localhost').pathname), ...(req.url.endsWith('/') ? ['index.html'] : []));
    if (!path.startsWith(root.endsWith(sep) ? root : root + sep)) throw new Error('Outside web root');
    const content = await readFile(path);
    res.writeHead(200,{'Content-Type':mime[extname(path)] ?? 'application/octet-stream','Cache-Control':'no-store'}).end(content);
  } catch { res.writeHead(404).end('Not found'); }
}).listen(Number(process.env.PORT ?? 4176),'127.0.0.1', () => console.log(`Test Report Delta: http://127.0.0.1:${process.env.PORT ?? 4176}/`));
