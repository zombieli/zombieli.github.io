import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_MODULE ?? 'playwright');
const base = process.env.BASE_URL ?? 'http://127.0.0.1:4176/';
const out = resolve(process.env.EVIDENCE_DIR ?? 'evidence');
await mkdir(out,{recursive:true});
const browser = await chromium.launch({headless:true, ...(process.env.CHROMIUM_PATH ? {executablePath:process.env.CHROMIUM_PATH} : {})});
const page = await browser.newPage({viewport:{width:1440,height:1000}});
const errors = [];
page.on('pageerror', e => errors.push(e.message));
const checks = [];
const check = async (name,work) => { await work(); checks.push({name,passed:true}); };
const file = (name,data) => ({name,mimeType:'application/json',buffer:Buffer.from(typeof data === 'string' ? data : JSON.stringify(data))});
const report = (name = 'check',status = 'passed') => ({schemaVersion:1,cases:[{suite:'safe',name,status,durationMs:100}]});
try {
  await page.goto(base);
  await check('Sample comparison classifies status, coverage and timing',async () => {
    await page.getByRole('button',{name:'Load sample comparison'}).click();
    await page.locator('#verdict').waitFor();
    assert.equal(await page.locator('#verdict').textContent(),'Action required');
    assert.equal(await page.locator('.case-row').count(),8);
    await page.getByRole('button',{name:'Failures',exact:true}).click();
    assert.equal(await page.locator('.case-row').count(),2);
    await page.getByRole('button',{name:'All cases',exact:true}).click();
  });
  await check('Replacing one report during sample loading still settles the untouched report',async () => {
    const pending=[];
    let ready;
    const requestsReady=new Promise(resolve => {ready=resolve;});
    await page.route('**/samples/*.json',route => {pending.push(route); if(pending.length===2) ready();});
    await page.getByRole('button',{name:'Load sample comparison'}).click();
    await requestsReady;
    const custom={...report(),label:'Custom candidate'};
    await page.locator('#candidate-file').setInputFiles(file('custom.json',custom));
    for(const route of pending) {
      const baseline=route.request().url().endsWith('/baseline.json');
      await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({...report(),label:baseline?'Delayed sample baseline':'Superseded sample candidate'})});
    }
    await page.waitForTimeout(50);
    assert.equal(await page.locator('#baseline-status').textContent(),'Delayed sample baseline · 1 tests');
    assert.equal(await page.locator('#candidate-status').textContent(),'Custom candidate · 1 tests');
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
    assert.equal(await page.locator('.report-labels').textContent(),'Delayed sample baseline → Custom candidate · 1 → 1 tests');
    await page.unroute('**/samples/*.json');
  });
  await page.getByRole('button',{name:'Load sample comparison'}).click();
  await page.getByText('Action required',{exact:true}).waitFor();
  await page.screenshot({path:resolve(out,'desktop.png'),fullPage:true});
  await check('Responsive layout has no horizontal document overflow',async () => {
    for (const width of [360,390,768,1440]) {
      await page.setViewportSize({width,height:900});
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
      if (width === 390) await page.screenshot({path:resolve(out,'mobile.png'),fullPage:true});
    }
  });
  await check('Imported files produce accepted verdict and downloadable JSON',async () => {
    await page.locator('#baseline-file').setInputFiles(file('baseline.json',report()));
    await page.locator('#candidate-file').setInputFiles(file('candidate.json',report()));
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
    const promise = page.waitForEvent('download');
    await page.getByRole('button',{name:'Download comparison JSON'}).click();
    const download = await promise;
    const path = await download.path();
    const {readFile} = await import('node:fs/promises');
    assert.equal(JSON.parse(await readFile(path,'utf8')).verdict,'pass');
  });
  await check('Malformed replacement clears stale accepted comparison',async () => {
    await page.locator('#candidate-file').setInputFiles(file('bad.json','{'));
    await page.locator('#error').waitFor({state:'visible'});
    assert.equal(await page.locator('#verdict').count(),0);
    assert.ok(await page.getByRole('button',{name:'Download comparison JSON'}).isDisabled());
    assert.equal(await page.locator('.case-row').count(),0);
  });
  await check('Hostile case names render as text and never execute',async () => {
    const hostile = '<img src=x onerror="window.__unsafe=1">';
    await page.locator('#baseline-file').setInputFiles(file('safe.json',report(hostile)));
    await page.locator('#candidate-file').setInputFiles(file('safe.json',report(hostile)));
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
    assert.equal(await page.locator('.case-name').textContent(),hostile);
    assert.equal(await page.locator('.case-name img').count(),0);
    assert.equal(await page.evaluate(() => window.__unsafe),undefined);
  });
  await check('New skips block acceptance until explicit policy selection',async () => {
    await page.locator('#candidate-file').setInputFiles(file('skip.json',report('<img src=x onerror="window.__unsafe=1">','skipped')));
    await page.getByText('Coverage incomplete',{exact:true}).waitFor();
    await page.getByText('Comparison policy',{exact:true}).click();
    await page.locator('#allow-skipped').check();
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
  });
  await check('Keyboard can reach primary action and file inputs have labels',async () => {
    await page.reload();
    await page.keyboard.press('Tab');
    assert.equal(await page.evaluate(() => document.activeElement.id),'sample');
    assert.equal(await page.getByLabel('Baseline JSON report').count(),1);
    assert.equal(await page.getByLabel('Candidate JSON report').count(),1);
  });
  await check('Superseded asynchronous file reads cannot restore a stale success',async () => {
    await page.locator('#baseline-file').setInputFiles(file('baseline.json',report()));
    await page.locator('#candidate-file').setInputFiles(file('candidate.json',report()));
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
    await page.evaluate(data => {
      const delayed=new File([JSON.stringify(data)],'delayed.json',{type:'application/json'});
      delayed.text=() => new Promise(resolve => { window.releaseDelayedRead=() => resolve(JSON.stringify(data)); });
      const transfer=new DataTransfer(); transfer.items.add(delayed);
      const input=document.querySelector('#candidate-file'); input.files=transfer.files; input.dispatchEvent(new Event('change',{bubbles:true}));
    },report());
    assert.equal(await page.locator('#verdict').count(),0);
    await page.locator('#candidate-file').setInputFiles(file('replacement.json','{'));
    await page.locator('#error').waitFor({state:'visible'});
    await page.evaluate(() => window.releaseDelayedRead());
    await page.waitForTimeout(40);
    assert.equal(await page.locator('#verdict').count(),0);
    assert.ok(await page.getByRole('button',{name:'Download comparison JSON'}).isDisabled());
  });
  await check('Invalid timing policy removes accepted results until repaired',async () => {
    await page.locator('#candidate-file').setInputFiles(file('repaired.json',report()));
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
    await page.getByText('Comparison policy',{exact:true}).click();
    await page.locator('#slowdown-ratio').fill('1');
    await page.locator('#error').waitFor({state:'visible'});
    assert.equal(await page.locator('#verdict').count(),0);
    await page.locator('#slowdown-ratio').fill('1.5');
    await page.getByText('Ready to proceed',{exact:true}).waitFor();
  });
  await check('Failure summary includes newly added failed cases',async () => {
    await page.locator('#baseline-file').setInputFiles(file('baseline.json',report('existing')));
    const candidate=report('existing');
    candidate.cases.push({suite:'safe',name:'new failed case',status:'failed',durationMs:10});
    await page.locator('#candidate-file').setInputFiles(file('candidate.json',candidate));
    await page.getByText('Action required',{exact:true}).waitFor();
    assert.equal(await page.locator('.metric.danger strong').textContent(),'1');
    await page.getByRole('button',{name:'Failures',exact:true}).click();
    assert.equal(await page.locator('.case-row').count(),1);
    assert.equal(await page.locator('.case-name').textContent(),'new failed case');
    await page.getByRole('button',{name:'All cases',exact:true}).click();
  });
  assert.deepEqual(errors,[]);
  const result = {checkedAt:new Date().toISOString(),baseUrl:base,browser:'Desktop Chromium',checks,consoleErrors:errors,screenshots:['desktop.png','mobile.png']};
  await writeFile(resolve(out,'browser-verification.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
} finally { await browser.close(); }
