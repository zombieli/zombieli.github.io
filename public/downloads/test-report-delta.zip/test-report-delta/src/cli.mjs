#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { compareReports, formatHuman, MAX_FILE_BYTES } from '../web/core.mjs';
const help = `Usage: node src/cli.mjs BASELINE.json CANDIDATE.json [options]
  --json                 Emit the deterministic comparison artifact
  --allow-removed        Permit missing baseline cases
  --allow-skipped        Permit newly skipped cases
  --slowdown-ratio N     Relative timing limit (default 1.5; greater than 1)
  --slowdown-ms N        Absolute timing limit (default 100; nonnegative)
  --help                Show this help
Exit codes: 0 accepted, 1 failed or incomplete, 2 invalid input or usage.
Timing warnings are advisory and require both strict limits to be exceeded.`;
try {
  const args = process.argv.slice(2);
  if (args.length === 1 && args[0] === '--help') { console.log(help); }
  else {
    const paths = [], options = {}; let json = false;
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (arg === '--json') json = true;
      else if (arg === '--allow-removed') options.allowRemoved = true;
      else if (arg === '--allow-skipped') options.allowSkipped = true;
      else if (arg === '--slowdown-ratio' || arg === '--slowdown-ms') {
        const value = args[++i];
        if (value === undefined || !value.trim() || !Number.isFinite(Number(value))) throw new Error(`Missing or invalid value for ${arg}`);
        options[arg === '--slowdown-ratio' ? 'slowdownRatio' : 'slowdownMs'] = Number(value);
      } else if (arg.startsWith('--')) throw new Error(`Unknown option ${arg}`);
      else paths.push(arg);
    }
    if (paths.length !== 2) throw new Error('Exactly two report paths are required. Use --help for usage.');
    const read = async path => {
      const data = await readFile(path);
      if (data.length > MAX_FILE_BYTES) throw new Error(`${path}: file exceeds 5 MiB limit`);
      try { return JSON.parse(data.toString('utf8')); } catch { throw new Error(`${path}: malformed JSON`); }
    };
    const [baseline,candidate] = await Promise.all(paths.map(read));
    const result = compareReports(baseline,candidate,options);
    console.log(json ? JSON.stringify(result,null,2) : formatHuman(result));
    process.exitCode = result.verdict === 'pass' ? 0 : 1;
  }
} catch (error) { console.error(`Error: ${error.message}`); process.exitCode = 2; }
