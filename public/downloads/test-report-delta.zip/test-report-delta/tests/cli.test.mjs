import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
const cli = fileURLToPath(new URL('../src/cli.mjs',import.meta.url));
const root = mkdtempSync(join(tmpdir(),'report-delta-'));
process.on('exit', () => rmSync(root,{recursive:true,force:true}));
const record = (status = 'passed') => ({ schemaVersion:1, cases:[{suite:'sample',name:'check',status,durationMs:100}] });
const put = (name, contents) => { const path = join(root,name); writeFileSync(path,typeof contents === 'string' ? contents : JSON.stringify(contents)); return path; };
const base = put('baseline.json',record());
const run = (...args) => spawnSync(process.execPath,[cli,...args],{encoding:'utf8'});
test('real CLI succeeds and emits deterministic parseable JSON', () => {
  const first = run(base,base,'--json'); const second = run(base,base,'--json');
  assert.equal(first.status,0); assert.equal(first.stderr,'');
  assert.equal(JSON.parse(first.stdout).verdict,'pass'); assert.equal(first.stdout,second.stdout);
});
test('real CLI returns exit one for regressions and incomplete coverage', () => {
  assert.equal(run(base,put('failed.json',record('failed'))).status,1);
  assert.equal(run(base,put('removed.json',{schemaVersion:1,cases:[]})).status,1);
  assert.equal(run(base,put('skipped.json',record('skipped'))).status,1);
});
test('explicit CLI policy permits new skips but never failures', () => {
  assert.equal(run(base,put('allow-skip.json',record('skipped')),'--allow-skipped').status,0);
  assert.equal(run(base,put('allow-fail.json',record('failed')),'--allow-skipped').status,1);
});
test('CLI prints human details and supports custom timing thresholds', () => {
  const candidate = record(); candidate.cases[0].durationMs = 150;
  const output = run(base,put('slow.json',candidate),'--slowdown-ratio','1.2','--slowdown-ms','20');
  assert.equal(output.status,0); assert.match(output.stdout,/slower/i); assert.match(output.stdout,/PASS/);
});
test('malformed JSON and unreadable files return exit two with no artifact', () => {
  for (const path of [put('bad.json','{'),join(root,'absent.json'),put('invalid.json',{schemaVersion:1,cases:[{}]})]) {
    const result = run(base,path,'--json'); assert.equal(result.status,2); assert.equal(result.stdout,''); assert.match(result.stderr,/Error:/);
  }
});
test('usage rejects unknown flags, missing options and invalid thresholds', () => {
  for (const args of [[],[base,base,'--wat'],[base,base,'--slowdown-ms'],[base,base,'--slowdown-ratio','NaN'],[base,base,'--slowdown-ms','-1'],[base,base,'extra']]) assert.equal(run(...args).status,2);
  assert.equal(run('--help').status,0);
});
