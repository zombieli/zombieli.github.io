import test from 'node:test';
import assert from 'node:assert/strict';
import { validateReport, compareReports, formatHuman } from '../web/core.mjs';
const item = (status = 'passed', durationMs = 100, name = 'case', suite = 'suite') => ({ suite, name, status, durationMs });
const report = (...cases) => ({ schemaVersion: 1, cases });

test('normalises reports without changing caller data', () => {
  const raw = report(item());
  const normal = validateReport(raw);
  assert.deepEqual(normal.cases, raw.cases);
  assert.notEqual(normal.cases[0], raw.cases[0]);
});
for (const [description, raw] of [
  ['missing version', { cases: [] }], ['wrong version', { schemaVersion: 2, cases: [] }],
  ['missing cases', { schemaVersion: 1 }], ['blank suite', report(item('passed', 2, 'name', ' '))],
  ['blank name', report(item('passed', 2, ' '))], ['unknown status', report(item('pending'))],
  ['negative timing', report(item('passed', -1))], ['infinite timing', report(item('passed', Infinity))],
  ['NaN timing', report(item('passed', NaN))], ['string timing', report(item('passed', '10'))],
  ['duplicate identity', report(item(), item('failed'))], ['null case', report(null)],
  ['non-string label', { ...report(), label: 2 }], ['null report', null],
]) test(`rejects ${description}`, () => assert.throws(() => validateReport(raw), /Invalid report/));

test('suite and name pairs cannot collide through separators', () => {
  assert.equal(validateReport(report(item('passed', 1, 'b:c', 'a'), item('passed', 1, 'c', 'a:b'))).cases.length, 2);
});
for (const [before, after, kind, verdict] of [
  ['passed','passed','unchanged','pass'], ['passed','failed','regression','fail'], ['passed','skipped','new-skipped','incomplete'],
  ['failed','passed','recovery','pass'], ['failed','failed','persistent-failure','fail'], ['failed','skipped','new-skipped','incomplete'],
  ['skipped','passed','resumed','pass'], ['skipped','failed','regression','fail'], ['skipped','skipped','unchanged','pass'],
]) test(`${before} to ${after} is ${kind} with ${verdict} verdict`, () => {
  const result = compareReports(report(item(before)), report(item(after)));
  assert.equal(result.rows[0].kind, kind);
  assert.equal(result.verdict, verdict);
});
test('removed coverage blocks acceptance unless explicitly permitted', () => {
  assert.equal(compareReports(report(item()), report()).verdict, 'incomplete');
  assert.equal(compareReports(report(item()), report(item('passed',1,'new case')), { allowRemoved: true }).verdict, 'pass');
});
test('added skipped and failed cases retain coverage and failure semantics', () => {
  const skipped = compareReports(report(), report(item('skipped')));
  assert.equal(skipped.counts.added, 1);
  assert.equal(skipped.counts.newSkipped, 1);
  assert.equal(skipped.verdict, 'incomplete');
  assert.equal(compareReports(report(), report(item('skipped')), { allowSkipped: true }).verdict, 'pass');
  assert.equal(compareReports(report(), report(item('failed')), { allowSkipped: true, allowRemoved: true }).verdict, 'fail');
});
test('empty candidate cannot be a successful release', () => {
  assert.equal(compareReports(report(), report()).verdict, 'incomplete');
});
test('ordering of input cases does not change JSON results', () => {
  const a = item('passed', 100, 'z'); const b = item('failed', 40, 'a');
  const left = compareReports(report(a,b), report(b,a));
  const right = compareReports(report(b,a), report(a,b));
  assert.equal(JSON.stringify(left), JSON.stringify(right));
  assert.equal(left.rows[0].name, 'a');
});
for (const [before, after, timing] of [[100,201,'slower'], [100,200,'stable'], [1000,1400,'stable'], [1,50,'stable'], [0,101,'slower'], [0,0,'stable'], [400,100,'faster']]) {
  test(`timing ${before} to ${after} is ${timing}`, () => {
    const result = compareReports(report(item('passed', before)), report(item('passed', after)));
    assert.equal(result.rows[0].timing, timing);
    assert.equal(result.verdict, 'pass');
    assert.ok(!JSON.stringify(result).includes('Infinity'));
  });
}
test('custom timing policy uses both strict thresholds', () => {
  assert.equal(compareReports(report(item('passed',100)), report(item('passed',130)), { slowdownRatio:1.2, slowdownMs:20 }).rows[0].timing, 'slower');
  for (const opts of [{ slowdownRatio:1 },{slowdownRatio:Infinity},{slowdownMs:-1},{allowRemoved:'yes'}]) assert.throws(() => compareReports(report(item()),report(item()),opts));
});
test('skipped and failed timings do not imply comparable passing performance', () => {
  assert.equal(compareReports(report(item('failed',1)),report(item('passed',999))).rows[0].timing,'unavailable');
});
test('human output explains incomplete coverage and policy', () => {
  const output = formatHuman(compareReports(report(item()), report()));
  assert.match(output, /INCOMPLETE/);
  assert.match(output, /removed/i);
});

