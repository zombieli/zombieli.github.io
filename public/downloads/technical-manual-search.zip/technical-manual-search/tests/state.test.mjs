import test from 'node:test';
import assert from 'node:assert/strict';
import { readState, writeState } from '../web/state.mjs';
test('query state URL round trips hostile text and filters', () => {
  const state = { query: '<img src=x> & battery', manual: 'aurora-beacon', category: 'Field equipment' };
  const url = writeState('https://example.test/demos/technical-manual-search/?other=keep#source', state);
  assert.deepEqual(readState(url), state);
  assert.equal(new URL(url).pathname, '/demos/technical-manual-search/');
  assert.equal(new URL(url).searchParams.get('other'), 'keep');
  assert.equal(new URL(url).hash, '');
});
test('empty state removes search parameters while retaining unrelated parameters', () => {
  const url = new URL(writeState('https://example.test/?q=old&manual=x&category=y&other=keep', { query: '', manual: '', category: '' }));
  assert.equal(url.search, '?other=keep');
  assert.deepEqual(readState(url), { query: '', manual: '', category: '' });
});
test('unknown URL filters are preserved so validation can explain the problem', () => {
  assert.equal(readState('https://example.test/?manual=missing').manual, 'missing');
});
