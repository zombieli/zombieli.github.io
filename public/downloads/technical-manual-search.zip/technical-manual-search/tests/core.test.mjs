import test from 'node:test';
import assert from 'node:assert/strict';
import { tokenize, buildIndex, search, validateCorpus, excerpt } from '../web/core.mjs';

const corpus = [
  { id: 'beacon', title: 'Beacon Manual', category: 'Inspection', revision: '1.0', sections: [
    { id: 'battery', title: 'Battery replacement', text: 'Disconnect power before battery replacement. Record the battery serial number.' },
    { id: 'lens', title: 'Lens cleaning', text: 'Clean the lens with a dry cloth. Check the lens for scratches.' }
  ] },
  { id: 'relay', title: 'Relay Manual', category: 'Maintenance', revision: '1.0', sections: [
    { id: 'battery', title: 'Battery storage', text: 'Store the battery in a cool cabinet. Keep the contacts covered.' }
  ] }
];

test('tokenizer normalises case, width, punctuation and ignores stop words', () => {
  assert.deepEqual(tokenize('  BATTERY / ＬＥＮＳ—the + power  '), ['battery', 'lens', 'power']);
});
test('HTML-like query text is treated as lexical input', () => {
  assert.deepEqual(tokenize('<img src=x onerror=alert(1)>'), ['img', 'src', 'x', 'onerror', 'alert', '1']);
});
test('corpus accepts local section IDs shared by different manuals', () => {
  assert.equal(validateCorpus(corpus).length, 2);
});
test('corpus rejects duplicate manual IDs and section IDs within a manual', () => {
  assert.throws(() => buildIndex([...corpus, corpus[0]]), /duplicate manual/i);
  assert.throws(() => buildIndex([{ ...corpus[0], sections: [corpus[0].sections[0], corpus[0].sections[0]] }]), /duplicate section/i);
});
test('corpus rejects invalid schema and bounded text violations', () => {
  for (const invalid of [null, [], [{ ...corpus[0], id: '../unsafe' }], [{ ...corpus[0], sections: [{ id: 'a', title: 'A', text: '' }] }]]) {
    assert.throws(() => buildIndex(invalid));
  }
  assert.throws(() => buildIndex([{ ...corpus[0], sections: [{ id: 'a', title: 'A', text: 'x'.repeat(20001) }] }]));
});
test('specific replacement query ranks relevant section first', () => {
  const results = search(buildIndex(corpus), 'battery replacement');
  assert.equal(results[0].reference, 'beacon#battery');
  assert.ok(results[0].score > results[1].score);
});
test('query repetition does not manipulate ranking', () => {
  const index = buildIndex(corpus);
  assert.deepEqual(search(index, 'battery battery battery'), search(index, 'battery'));
});
test('empty, stop-only and absent terms return no results', () => {
  const index = buildIndex(corpus);
  for (const query of ['', '   ', 'the and of', 'satellite']) assert.deepEqual(search(index, query), []);
});
test('input boundaries reject rather than silently truncate', () => {
  const index = buildIndex(corpus);
  assert.throws(() => search(index, 'x'.repeat(241)), /240/);
  assert.throws(() => search(index, {}), /string/i);
  assert.throws(() => search(index, 'battery', { limit: 0 }), /limit/i);
  assert.throws(() => search(index, 'battery', { limit: 51 }), /limit/i);
  assert.doesNotThrow(() => search(index, 'x'.repeat(240)));
  assert.throws(() => search(index, Array.from({ length: 65 }, (_, n) => `z${n.toString(36)}`).join(' ')), /64 unique/);
  assert.doesNotThrow(() => search(index, Array.from({ length: 64 }, (_, n) => `z${n.toString(36)}`).join(' ')));
});
test('manual and category filters intersect and reject unknown selections', () => {
  const index = buildIndex(corpus);
  assert.deepEqual(search(index, 'battery', { manual: 'relay' }).map(x => x.reference), ['relay#battery']);
  assert.equal(search(index, 'battery', { category: 'Inspection' }).length, 1);
  assert.deepEqual(search(index, 'battery', { manual: 'relay', category: 'Inspection' }), []);
  assert.throws(() => search(index, 'battery', { manual: 'missing' }), /manual/i);
  assert.throws(() => search(index, 'battery', { category: 'missing' }), /category/i);
});
test('stable ties and ranking are independent of corpus input order', () => {
  const tied = ['z', 'a'].map(id => ({ id, title: 'Same', category: 'Test', revision: '1', sections: [{ id: 'one', title: 'Equal', text: 'equal battery words' }] }));
  assert.deepEqual(search(buildIndex(tied), 'battery').map(x => x.reference), ['a#one', 'z#one']);
  const reversed = [...corpus].reverse().map(m => ({ ...m, sections: [...m.sections].reverse() }));
  assert.deepEqual(search(buildIndex(corpus), 'battery'), search(buildIndex(reversed), 'battery'));
});
test('results preserve exact source attribution without exposing mutable index data', () => {
  const index = buildIndex(corpus);
  const result = search(index, 'replacement')[0];
  assert.equal(result.sourceText, corpus[0].sections[0].text);
  assert.equal(result.manualTitle, 'Beacon Manual');
  assert.equal(result.sectionId, 'battery');
  assert.deepEqual(result.matchedTerms, ['replacement']);
  result.sourceText = 'changed';
  assert.equal(search(index, 'replacement')[0].sourceText, corpus[0].sections[0].text);
});
test('excerpt is bounded and centres a late matching term', () => {
  const source = `${'alpha '.repeat(80)}battery ${'omega '.repeat(80)}`;
  const result = excerpt(source, ['battery'], 100);
  assert.ok(result.includes('battery'));
  assert.ok(result.length <= 104);
});
