import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const cli = fileURLToPath(new URL('../scripts/search.mjs', import.meta.url));
const run = args => spawnSync(process.execPath, [cli, ...args], { encoding: 'utf8' });
test('CLI uses shared search and emits attributable JSON', () => {
  const result = run(['battery replacement', '--json']);
  assert.equal(result.status, 0, result.stderr);
  const output = JSON.parse(result.stdout);
  assert.equal(output[0].reference, 'aurora-beacon#battery-replacement');
  assert.ok(output[0].sourceText.includes('B7 practice pack'));
});
test('CLI filter yields an empty valid result and an unknown filter is an error', () => {
  const empty = run(['battery', '--manual', 'cedar-logger', '--json']);
  assert.equal(empty.status, 0, empty.stderr);
  assert.deepEqual(JSON.parse(empty.stdout), []);
  assert.equal(run(['battery', '--manual', 'missing']).status, 2);
});
test('CLI rejects excess input, invalid flags and missing arguments', () => {
  for (const args of [[], ['battery', '--limit', '0'], ['battery', '--limit', 'no'], ['battery', '--unknown'], ['battery', '--manual'], ['x'.repeat(241)]]) assert.equal(run(args).status, 2, args.join(' '));
});
test('CLI output is deterministic across subprocess runs', () => {
  assert.equal(run(['cable', '--json']).stdout, run(['cable', '--json']).stdout);
});
