import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { evaluate } from '../scripts/metrics.mjs';
import { buildIndex } from '../web/core.mjs';
const corpus = JSON.parse(readFileSync(new URL('../web/data/manuals.json', import.meta.url)));
test('published corpus has valid references for every relevance judgement', () => {
  const queries = JSON.parse(readFileSync(new URL('../fixtures/queries.json', import.meta.url)));
  const references = new Set(corpus.flatMap(m => m.sections.map(s => `${m.id}#${s.id}`)));
  assert.ok(references.size >= 12);
  assert.ok(corpus.length >= 3);
  for (const query of queries) for (const reference of query.relevant) assert.ok(references.has(reference), reference);
  assert.equal(new Set(queries.map(q => q.id)).size, queries.length);
});
test('evaluation includes misses in positive metric denominators', () => {
  const queries = [
    { id: 'hit', kind: 'positive', query: 'battery replacement', relevant: ['aurora-beacon#battery-replacement'] },
    { id: 'miss', kind: 'positive', query: 'zzzz', relevant: ['aurora-beacon#battery-replacement'] }
  ];
  const report = evaluate(buildIndex(corpus), queries, 3);
  assert.equal(report.positive.count, 2);
  assert.equal(report.positive.mrr, 0.5);
  assert.equal(report.positive.recallAtK, 0.5);
  assert.equal(report.positive.hitAtK, 0.5);
  assert.equal(report.rows[1].reciprocalRank, 0);
});
test('unsupported lexical overlaps are reported as negative false positives', () => {
  const queries = [
    { id: 'empty', kind: 'negative', query: 'zzzz', relevant: [] },
    { id: 'unsupported', kind: 'unanswerable', query: 'battery warranty', relevant: [] }
  ];
  const report = evaluate(buildIndex(corpus), queries, 3);
  assert.equal(report.negative.count, 2);
  assert.equal(report.negative.emptyResultRate, 0.5);
  assert.equal(report.negative.falsePositiveRate, 0.5);
  assert.equal(report.positive.count, 0);
  assert.equal(report.positive.mrr, null);
});
test('invalid evaluation labels are rejected', () => {
  const index = buildIndex(corpus);
  for (const invalid of [[], [{ id: 'x', kind: 'positive', query: 'battery', relevant: [] }], [{ id: 'x', kind: 'negative', query: 'x', relevant: ['unknown#x'] }]]) assert.throws(() => evaluate(index, invalid, 3));
});
