# Search evaluation

Reproduce with `npm run evaluate`. The JSON report records every judgement and returned reference.

Corpus: 3 original fictional manuals, 15 sections. Query set: 26 labelled queries (18 positive, 8 negative or unanswerable). Cutoff: 5; ranking depth: 50.

| Positive metric | Measured value |
| --- | ---: |
| Mean reciprocal rank | 0.944444 |
| Mean recall@5 | 0.944444 |
| Hit@5 | 94.44% |
| Misses@5 | p17 |

| Negative behavior | Measured value |
| --- | ---: |
| Empty result sets | 4/8 (50.00%) |
| Lexical false positives | 4/8 (50.00%) |

Positive metrics use only positive labels and include zero scores for misses. Negative queries contribute only to the negative behavior metrics. Recall@k is the mean fraction of labelled relevant sections found among the top k; hit@k is the proportion with at least one relevant section. MRR is the mean reciprocal rank of the first relevant section.

The “download readings” query is retained as a realistic paraphrase miss. Unsupported questions about battery warranty, CSV encryption, cart load rating and lens price can still share words with source text. These are measured false positives, not answers. No ranking threshold has been fitted to hide these cases.

- Original fictional training data; not an independent benchmark.
- Relevance labels are project-authored and reviewed against the corpus.
- Exact terms only: no stemming, synonyms, semantic retrieval or generated answers.
- Negative false positives are lexical matches to unsupported questions, not valid answers.
- MRR uses up to 50 ranks; the present corpus has 15 sections. All positive queries, including misses, are counted.

Corpus SHA-256: `d5e8ad50884382c809e9fbd3a95264881ce1d7a6376096a757629fabe00f1a46`

Query-set SHA-256: `3bafaaf06896eac314084c8df6ea692c7e638fa8e721056f870a93bc99b95383`
