import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(fileURLToPath(new URL('../web/', import.meta.url)));
const port = Number(process.env.PORT || 4177);
const prefix = '/demos/technical-manual-search/';
const types = { '.html': 'text/html', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml' };
http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    if (url.pathname === '/demos/technical-manual-search') { response.writeHead(302, { Location: prefix }).end(); return; }
    let path = decodeURIComponent(url.pathname);
    if (path.startsWith(prefix)) path = path.slice(prefix.length); else path = path.slice(1);
    const file = resolve(root, path || 'index.html');
    if (file !== root && !file.startsWith(root + sep)) throw new Error('Invalid path.');
    const extension = file.slice(file.lastIndexOf('.'));
    const body = await readFile(file);
    response.writeHead(200, { 'Content-Type': `${types[extension] || 'application/octet-stream'}; charset=utf-8`, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }).end(body);
  } catch { response.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found'); }
}).listen(port, '127.0.0.1', () => console.log(`Reference Desk: http://127.0.0.1:${port}${prefix}`));
