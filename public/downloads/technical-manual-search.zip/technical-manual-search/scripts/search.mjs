import { readFile } from 'node:fs/promises';
import { buildIndex, search } from '../web/core.mjs';

try {
  const args = process.argv.slice(2);
  if (args.length === 1 && args[0] === '--help') {
    console.log('Usage: node scripts/search.mjs "query" [--manual ID] [--category NAME] [--limit 1..50] [--json]\nExit 0: valid search, including no matches. Exit 2: invalid arguments or data.');
  } else {
    const query = args.shift();
    if (!query || query.startsWith('--')) throw new Error('Provide a query as the first argument. Use --help for usage.');
    const options = {}, seen = new Set(); let json = false;
    while (args.length) {
      const flag = args.shift();
      if (seen.has(flag)) throw new Error(`Repeated option: ${flag}`);
      seen.add(flag);
      if (flag === '--json') { json = true; continue; }
      if (!['--manual', '--category', '--limit'].includes(flag)) throw new Error(`Unknown option: ${flag}`);
      const value = args.shift();
      if (!value || value.startsWith('--')) throw new Error(`Missing value for ${flag}.`);
      options[flag.slice(2)] = flag === '--limit' ? Number(value) : value;
    }
    const index = buildIndex(JSON.parse(await readFile(new URL('../web/data/manuals.json', import.meta.url), 'utf8')));
    const results = search(index, query, options);
    if (json) console.log(JSON.stringify(results, null, 2));
    else if (!results.length) console.log('No matching sections.');
    else results.forEach((result, position) => console.log(`${position + 1}. ${result.manualTitle} / ${result.sectionTitle}\n   ${result.reference} · revision ${result.revision} · ${result.matchedTerms.length}/${result.queryTermCount} terms matched\n   ${result.excerpt}\n`));
  }
} catch (error) {
  console.error(`Search error: ${error.message}`); process.exitCode = 2;
}
