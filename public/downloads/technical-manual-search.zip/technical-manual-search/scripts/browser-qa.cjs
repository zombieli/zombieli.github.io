const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');

const baseURL = process.env.BASE_URL || 'http://127.0.0.1:4177/demos/technical-manual-search/';
const evidenceDir = path.resolve(__dirname, '../evidence');
const checks = [], errors = [], externalRequests = [];
async function check(name, action) { await action(); checks.push({ name, passed: true }); }

(async () => {
  await fs.mkdir(path.join(evidenceDir, 'screenshots'), { recursive: true });
  const browser = await chromium.launch({ headless: true, ...(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {}) });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
  const dialogs = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('dialog', async dialog => { dialogs.push(dialog.message()); await dialog.dismiss(); });
  page.on('request', request => { if (!request.url().startsWith(new URL(baseURL).origin)) externalRequests.push(request.url()); });
  const ready = async () => { await page.waitForFunction(() => !document.getElementById('search-status').textContent.includes('Loading')); };
  const submit = async query => {
    await page.locator('#search-query').fill(query);
    await page.locator('#search-form button[type=submit]').click();
  };
  try {
    await check('Initial empty state and loaded collection', async () => {
      await page.goto(baseURL); await ready();
      assert.match(await page.locator('#results').innerText(), /Your next reference/);
      assert.equal(await page.locator('#manual-filter option').count(), 4);
      assert.equal(await page.locator('.result').count(), 0);
    });
    await check('Keyboard search and canonical result attribution', async () => {
      await page.locator('#search-query').fill('battery replacement');
      await page.locator('#search-query').press('Enter');
      assert.equal(await page.locator('.result h3').first().textContent(), 'Replace the training battery');
      assert.equal(await page.locator('.reference-link').first().textContent(), 'aurora-beacon#battery-replacement');
      assert.equal(new URL(page.url()).searchParams.get('q'), 'battery replacement');
      await page.locator('.result summary').first().click();
      const corpus = await (await page.request.get(new URL('./data/manuals.json', baseURL).href)).json();
      assert.equal(await page.locator('.source-text').first().textContent(), corpus[0].sections[1].text);
      assert.ok(await page.locator('.result mark').count() > 0);
    });
    await check('Desktop evidence screenshot', async () => {
      await page.evaluate(() => { document.activeElement.blur(); window.scrollTo(0, 0); });
      await page.screenshot({ path: path.join(evidenceDir, 'screenshots/manual-search-desktop.png'), fullPage: true });
    });
    await check('Query URL survives reload', async () => {
      await page.reload(); await ready();
      assert.equal(await page.locator('#search-query').inputValue(), 'battery replacement');
      assert.equal(await page.locator('.reference-link').first().textContent(), 'aurora-beacon#battery-replacement');
    });
    await check('No lexical matches returns no cards', async () => {
      await submit('satellite ephemeris');
      assert.equal(await page.locator('.result').count(), 0);
      assert.match(await page.locator('#results').innerText(), /No matching sections/);
    });
    await check('Browser back and forward restore query and results', async () => {
      await page.goBack();
      assert.equal(await page.locator('#search-query').inputValue(), 'battery replacement');
      assert.ok(await page.locator('.result').count() > 0);
      await page.goForward();
      assert.equal(await page.locator('#search-query').inputValue(), 'satellite ephemeris');
      assert.equal(await page.locator('.result').count(), 0);
    });
    await check('Manual and category filters persist and intersect', async () => {
      await page.locator('#manual-filter').selectOption('cedar-logger');
      await page.locator('#category-filter').selectOption('Data handling');
      await submit('CSV');
      assert.ok(await page.locator('.result').count() > 0);
      for (const reference of await page.locator('.reference-link').allTextContents()) assert.ok(reference.startsWith('cedar-logger#'));
      await page.reload(); await ready();
      assert.equal(await page.locator('#manual-filter').inputValue(), 'cedar-logger');
      assert.equal(await page.locator('#category-filter').inputValue(), 'Data handling');
      await page.locator('#category-filter').selectOption('Workshop practice'); await submit('CSV');
      assert.equal(await page.locator('.result').count(), 0);
    });
    await check('Unknown URL filter errors and recovers with valid selection', async () => {
      await page.goto(`${baseURL}?q=battery&manual=unknown`); await ready();
      assert.match(await page.locator('#search-status').textContent(), /Unknown manual filter/);
      assert.equal(await page.locator('.result').count(), 0);
      assert.equal(await page.locator('#search-query').inputValue(), 'battery');
      await page.locator('#manual-filter').selectOption(''); await submit('battery');
      assert.ok(await page.locator('.result').count() > 0);
      assert.equal(new URL(page.url()).searchParams.has('manual'), false);
      await page.goto(`${baseURL}?q=battery&category=unknown`); await ready();
      assert.match(await page.locator('#search-status').textContent(), /Unknown category filter/);
      await page.locator('#category-filter').selectOption(''); await submit('battery');
      assert.ok(await page.locator('.result').count() > 0);
    });
    await check('Oversized URL query is rejected and editable', async () => {
      await page.goto(`${baseURL}?q=${'x'.repeat(241)}`); await ready();
      assert.match(await page.locator('#search-status').textContent(), /240 characters/);
      assert.equal(await page.locator('.result').count(), 0);
      await submit('lens'); assert.ok(await page.locator('.result').count() > 0);
    });
    await check('Hostile query and source markup are rendered as text', async () => {
      const hostile = '<img src=x onerror=alert(1)>';
      await submit(hostile);
      assert.ok((await page.locator('#search-status').textContent()).includes(hostile));
      assert.ok((await page.locator('#results').textContent()).includes(hostile));
      assert.equal(await page.locator('#results img, #results script, #search-status img').count(), 0);
      await page.locator('.result summary').first().click();
      assert.ok((await page.locator('.source-text').first().textContent()).includes(hostile));
      assert.deepEqual(dialogs, []);
    });
    await check('Source fragment opens full source after reload', async () => {
      await submit('battery replacement');
      await page.locator('.reference-link').first().click();
      assert.ok(new URL(page.url()).hash.includes('aurora-beacon.battery-replacement'));
      await page.reload(); await ready();
      assert.equal(await page.locator('.result details').first().getAttribute('open'), '');
    });
    await check('Empty and stop-only queries clear previous results', async () => {
      await submit('the and of'); assert.equal(await page.locator('.result').count(), 0);
      await submit(''); assert.equal(await page.locator('.result').count(), 0);
      assert.match(await page.locator('#results').innerText(), /Your next reference/);
    });
    await check('Topic button replaces incompatible filters', async () => {
      await page.locator('#manual-filter').selectOption('mariner-cart');
      await page.locator('[data-query="battery replacement"]').click();
      assert.equal(await page.locator('#manual-filter').inputValue(), '');
      assert.equal(await page.locator('.reference-link').first().textContent(), 'aurora-beacon#battery-replacement');
    });
    await check('360, 390, 768 and 1440px layouts have no horizontal overflow', async () => {
      for (const width of [360, 390, 768, 1440]) {
        await page.setViewportSize({ width, height: 900 });
        assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `Overflow at ${width}`);
        const box = await page.locator('#search-form button[type=submit]').boundingBox();
        assert.ok(box.height >= 44);
        if (width === 390) {
          await page.evaluate(() => { document.activeElement.blur(); window.scrollTo(0, 0); });
          assert.ok((await page.locator('.skip').boundingBox()).y < 0);
          await page.screenshot({ path: path.join(evidenceDir, 'screenshots/manual-search-mobile.png'), fullPage: true });
        }
      }
    });
    await check('Unavailable collection has a visible error and disabled search', async () => {
      const failed = await browser.newPage();
      await failed.route('**/data/manuals.json', route => route.fulfill({ status: 200, contentType: 'application/json', body: '{"invalid":true}' }));
      await failed.goto(baseURL);
      await failed.waitForFunction(() => document.getElementById('search-status').classList.contains('error'));
      assert.equal(await failed.locator('#search-query').isDisabled(), true);
      assert.equal(await failed.locator('.result').count(), 0);
      assert.match(await failed.locator('#result-count').textContent(), /unavailable/);
      await failed.close();
    });
    await check('Distinct source references produce collision-free fragment IDs', async () => {
      const corner = await browser.newPage();
      const corpus = [
        { id: 'a--b', title: 'First manual', category: 'Test', revision: '1', sections: [{ id: 'c', title: 'Battery first', text: 'battery first source' }] },
        { id: 'a', title: 'Second manual', category: 'Test', revision: '1', sections: [{ id: 'b--c', title: 'Battery second', text: 'battery second source' }] }
      ];
      await corner.route('**/data/manuals.json', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(corpus) }));
      await corner.goto(`${baseURL}?q=battery`);
      await corner.waitForFunction(() => document.querySelectorAll('.result').length === 2);
      const ids = await corner.locator('.result').evaluateAll(nodes => nodes.map(node => node.id));
      assert.equal(new Set(ids).size, 2);
      await corner.close();
    });
    await check('No page errors, dialogs or external network requests', async () => {
      assert.deepEqual(errors, []); assert.deepEqual(dialogs, []); assert.deepEqual(externalRequests, []);
    });
    const report = { schemaVersion: 1, executedAt: new Date().toISOString(), baseURL, browser: `Chromium ${browser.version()}`, nativeDeviceTesting: false,
      checks, passed: checks.length, failed: 0, screenshots: ['evidence/screenshots/manual-search-desktop.png', 'evidence/screenshots/manual-search-mobile.png'],
      limitations: ['Desktop Chromium with viewport emulation; no native phone testing.', 'Checks use a local HTTP server; deployment verification is separate.'] };
    await fs.writeFile(path.join(evidenceDir, 'browser-report.json'), `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify({ passed: checks.length, failed: 0, screenshots: report.screenshots }));
  } catch (error) {
    await fs.writeFile(path.join(evidenceDir, 'browser-report.json'), `${JSON.stringify({ schemaVersion: 1, executedAt: new Date().toISOString(), baseURL, checks, passed: checks.length, failed: 1, error: error.message }, null, 2)}\n`);
    throw error;
  } finally { await browser.close(); }
})().catch(error => { console.error(error.message); process.exitCode = 1; });
