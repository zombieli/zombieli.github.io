import { spawnSync } from 'node:child_process';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = fileURLToPath(new URL('../', import.meta.url));
const files = (await readdir(new URL('../tests/', import.meta.url))).filter(name => name.endsWith('.test.mjs')).sort().map(name => `tests/${name}`);
const tests = spawnSync(process.execPath, ['--test', '--test-reporter=tap', ...files], { cwd: root, encoding: 'utf8' });
if (tests.status !== 0) { console.error(tests.stdout, tests.stderr); process.exit(1); }
const metric = name => Number(tests.stdout.match(new RegExp(`# ${name} (\\d+)`))?.[1] ?? NaN);
if (!Number.isFinite(metric('tests')) || metric('fail') !== 0) throw new Error('Could not validate test summary.');
const runEvaluation = () => {
  const result = spawnSync(process.execPath, ['scripts/evaluate.mjs'], { cwd: root, encoding: 'utf8' });
  if (result.status !== 0) throw new Error(`Evaluation failed: ${result.stderr}`);
};
runEvaluation();
const first = await readFile(new URL('../evidence/evaluation.json', import.meta.url), 'utf8');
runEvaluation();
const second = await readFile(new URL('../evidence/evaluation.json', import.meta.url), 'utf8');
if (first !== second) throw new Error('Evaluation is not reproducible.');
const evaluation = JSON.parse(second);
const browser = JSON.parse(await readFile(new URL('../evidence/browser-report.json', import.meta.url), 'utf8'));
if (browser.failed !== 0 || !browser.passed || browser.checks.some(check => !check.passed)) throw new Error('Browser verification must pass before evidence is combined.');
const report = {
  schemaVersion: 1, project: 'technical-manual-search', version: '1.1.0', verifiedAt: new Date().toISOString(),
  runtime: { node: process.version, runtimeDependencies: 0 },
  tests: { command: 'node --test tests/*.test.mjs', total: metric('tests'), passed: metric('pass'), failed: metric('fail'), skipped: metric('skipped') },
  browser: { command: 'node scripts/browser-qa.cjs', passed: browser.passed, failed: browser.failed, browser: browser.browser, executedAt: browser.executedAt, nativeDeviceTesting: false, report: 'evidence/browser-report.json', screenshots: browser.screenshots },
  evaluation: { command: 'node scripts/evaluate.mjs', totalQueries: evaluation.totalQueries, positive: evaluation.positive, negative: evaluation.negative, k: evaluation.k, rankDepth: evaluation.rankDepth, corpus: evaluation.corpus, querySetSha256: evaluation.querySetSha256, report: 'evidence/evaluation.json', reproducedIdentically: true, reportSha256: createHash('sha256').update(second).digest('hex') },
  testFirst: { core: { total: 13, failedBeforeImplementation: 11 }, urlState: { total: 3, failedBeforeImplementation: 3 }, evaluation: { total: 4, failedBeforeImplementation: 3 }, cli: { total: 4, failedBeforeImplementation: 2 }, record: 'docs/development-log.md' },
  limitations: ['Original fictional data and project-authored relevance labels; not an independent benchmark.', 'One positive paraphrase misses; four unsupported questions return lexical matches.', 'Desktop Chromium viewport checks do not establish native-phone behavior.', 'Local HTTP evidence; deployment checks are separate.', 'No offline cache, semantic search or generated answers.']
};
await writeFile(new URL('../evidence/verification.json', import.meta.url), `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ tests: report.tests, browser: report.browser.passed, evaluationReproducedIdentically: true }));
