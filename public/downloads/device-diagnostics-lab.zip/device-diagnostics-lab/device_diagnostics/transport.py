"""A real TCP adapter with a deadline and bounded response frame."""

import socket
import time
from typing import Protocol

from .protocol import DiagnosticError, MAX_FRAME_BYTES, decode_frame, encode_frame


class Adapter(Protocol):
    def request(self, payload: dict, timeout_s: float) -> dict: ...


class TcpAdapter:
    def __init__(self, host: str, port: int):
        self.host, self.port = host, port

    def request(self, payload: dict, timeout_s: float) -> dict:
        deadline = time.monotonic() + timeout_s
        try:
            with socket.create_connection((self.host, self.port), timeout=timeout_s) as connection:
                connection.settimeout(max(0.001, deadline - time.monotonic()))
                connection.sendall(encode_frame(payload))
                data = bytearray()
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise DiagnosticError("timeout", "Response deadline exceeded")
                    connection.settimeout(remaining)
                    chunk = connection.recv(min(4096, MAX_FRAME_BYTES + 1 - len(data)))
                    if not chunk:
                        code = "protocol_error" if data else "connection_error"
                        raise DiagnosticError(code, "Peer closed before a complete response")
                    data.extend(chunk)
                    if len(data) > MAX_FRAME_BYTES:
                        raise DiagnosticError("protocol_error", "Response exceeds frame size limit")
                    if b"\n" in data:
                        frame, remainder = data.split(b"\n", 1)
                        if remainder.strip():
                            raise DiagnosticError("protocol_error", "Unexpected data after response")
                        return decode_frame(bytes(frame))
        except (socket.timeout, TimeoutError) as exc:
            raise DiagnosticError("timeout", "Connection or response timed out") from exc
        except OSError as exc:
            raise DiagnosticError("connection_error", f"TCP connection failed: {type(exc).__name__}") from exc
