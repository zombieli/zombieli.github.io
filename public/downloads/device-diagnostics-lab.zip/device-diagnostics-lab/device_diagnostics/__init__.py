"""Experimental diagnostics protocol; no physical-device certification implied."""

__version__ = "0.1.0"
