import argparse
import json
from pathlib import Path

from .config import demo_config
from .reporting import write_report
from .runner import execute
from .simulator import SimulatorServer, running_simulator


def main(argv=None):
    parser = argparse.ArgumentParser(description="Device Diagnostics Lab — local simulator evidence, not hardware certification")
    commands = parser.add_subparsers(dest="command", required=True)
    demo = commands.add_parser("demo", help="Start a local simulator and run 11 fault scenarios")
    demo.add_argument("--output", type=Path, default=Path("reports"))
    demo.add_argument("--unexpected-failure", action="store_true", help="Require a valid response in the missing-field scenario")
    run = commands.add_parser("run", help="Run a JSON configuration against the local simulator")
    run.add_argument("--config", type=Path, required=True)
    run.add_argument("--output", type=Path, default=Path("reports"))
    serve = commands.add_parser("serve", help="Start simulator on 127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    args = parser.parse_args(argv)
    try:
        if args.command == "serve":
            if not 0 <= args.port <= 65535:
                raise ValueError("Port must be from 0 to 65535")
            with SimulatorServer(("127.0.0.1", args.port)) as server:
                print(f"Simulator listening on 127.0.0.1:{server.server_address[1]}", flush=True)
                server.serve_forever(poll_interval=0.05)
            return 0
        if args.command == "demo":
            with running_simulator() as server:
                report = execute(demo_config(server.server_address[1], args.unexpected_failure))
        else:
            report = execute(json.loads(args.config.read_text(encoding="utf-8-sig")))
        path = write_report(report, args.output)
        print("Evidence origin: simulator (TCP loopback)")
        for case in report["cases"]:
            print(f"{case['case_id']} {case['outcome'].upper():5} {case['scenario']:<25} "
                  f"diagnostic={case['diagnostic']:<17} attempts={case['attempt_count']}")
        print(json.dumps(report["summary"]))
        print(f"Report: {path / 'report.json'}")
        return 1 if report["summary"]["fail"] or report["summary"]["error"] else 0
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, TypeError) as exc:
        print(f"Cannot complete run: {exc}")
        return 2
