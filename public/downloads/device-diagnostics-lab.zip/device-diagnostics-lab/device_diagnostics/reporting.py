"""Publish a complete report directory only after all files have been written."""

import csv
import json
from pathlib import Path


def write_report(report: dict, output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)
    destination = output / report["run_id"]
    pending = output / ("_pending-" + report["run_id"])
    if destination.exists():
        raise FileExistsError(f"Report already exists: {destination}")
    pending.mkdir()  # Never silently overwrite an earlier incomplete run either.
    (pending / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    with (pending / "cases.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = ["case_id", "requirement_id", "scenario", "expected", "diagnostic", "outcome", "attempt_count", "duration_ms"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for case in report["cases"]:
            writer.writerow({field: case[field] for field in fields})
    with (pending / "events.jsonl").open("w", encoding="utf-8") as handle:
        for case in report["cases"]:
            for attempt in case["attempts"]:
                handle.write(json.dumps({"run_id": report["run_id"], "case_id": case["case_id"], **attempt}, allow_nan=False) + "\n")
    pending.rename(destination)
    return destination
