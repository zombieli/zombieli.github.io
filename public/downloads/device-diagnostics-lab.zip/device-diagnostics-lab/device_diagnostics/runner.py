"""Runner separates observed diagnostic faults from test expectation outcomes."""

import hashlib
import platform
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from . import __version__
from .config import validate_config
from .protocol import DiagnosticError, PROTOCOL, validate_status
from .transport import TcpAdapter


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def source_digest():
    digest = hashlib.sha256()
    for file in sorted(Path(__file__).parent.glob("*.py")):
        digest.update(file.name.encode())
        digest.update(file.read_bytes())
    return digest.hexdigest()


def execute(config: dict, adapter=None) -> dict:
    validate_config(config)
    adapter = adapter or TcpAdapter(**config["target"])
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    report = {
        "schema_version": 1, "run_id": run_id, "started_at_utc": utc_now(),
        "version": __version__, "source_sha256": source_digest(),
        "environment": {"python": platform.python_version(), "platform": platform.system()},
        "adapter_type": "tcp-jsonl", "evidence_origin": "simulator",
        "device_or_simulator": "LAB-SIM-001", "protocol": PROTOCOL,
        "config": config, "cases": [],
    }
    for case in config["cases"]:
        start = time.monotonic()
        attempts, actual, error_code, error_message = [], None, None, None
        for number in range(1, config["max_attempts"] + 1):
            request_id = uuid.uuid4().hex
            payload = {"protocol": PROTOCOL, "request_id": request_id,
                       "run_case_id": run_id + ":" + case["case_id"],
                       "operation": "get_status", "scenario": case["scenario"]}
            attempt = {"attempt": number, "started_at_utc": utc_now(), "request": payload}
            attempt_start = time.monotonic()
            try:
                raw_response = adapter.request(payload, config["timeout_s"])
                attempt["response"] = raw_response
                actual = validate_status(raw_response, request_id)
                error_code, error_message = None, None
                attempt["diagnostic"] = "ok"
            except DiagnosticError as exc:
                actual = None
                error_code, error_message = exc.code, str(exc)
                attempt.update(diagnostic=error_code, message=error_message)
            except Exception as exc:
                actual = None
                error_code, error_message = "internal_error", f"{type(exc).__name__}: {exc}"
                attempt.update(diagnostic=error_code, message=error_message)
            attempt["duration_ms"] = round((time.monotonic() - attempt_start) * 1000, 3)
            attempts.append(attempt)
            if error_code not in {"timeout", "connection_error"}:
                break
        if error_code == "internal_error":
            outcome = "error"
        else:
            outcome = "pass" if error_code == case["expected_error"] else "fail"
        report["cases"].append({
            **case, "expected": case["expected_error"] or "valid_status",
            "actual": actual, "diagnostic": error_code or "ok", "message": error_message,
            "outcome": outcome, "duration_ms": round((time.monotonic() - start) * 1000, 3),
            "attempt_count": len(attempts), "attempts": attempts,
        })
    report["finished_at_utc"] = utc_now()
    report["summary"] = {key: sum(c["outcome"] == key for c in report["cases"])
                         for key in ("pass", "fail", "error", "skipped")}
    report["summary"]["total"] = len(report["cases"])
    report["summary"]["diagnostic_faults"] = sum(c["diagnostic"] != "ok" for c in report["cases"])
    return report
