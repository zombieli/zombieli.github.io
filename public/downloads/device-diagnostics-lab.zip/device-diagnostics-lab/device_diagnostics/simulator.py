"""Local TCP fixture. Scenarios are explicitly requested by the test client."""

import json
import socket
import socketserver
import threading
from contextlib import contextmanager

from .protocol import MAX_FRAME_BYTES, PROTOCOL, SCENARIOS, encode_frame


class SimulatorHandler(socketserver.StreamRequestHandler):
    def handle(self):
        self.connection.settimeout(2)
        try:
            line = self.rfile.readline(MAX_FRAME_BYTES + 1)
            if len(line) > MAX_FRAME_BYTES or not line.endswith(b"\n"):
                return
            request = json.loads(line)
            if not isinstance(request, dict):
                return
            scenario = request.get("scenario", "normal")
            if (request.get("protocol") != PROTOCOL or request.get("operation") != "get_status"
                    or scenario not in SCENARIOS):
                self.wfile.write(encode_frame({"error": "unsupported_request"}))
                return
            if scenario == "timeout":
                # Withhold a response until the client closes after its own deadline.
                self.connection.recv(1)
                return
            if scenario == "disconnect":
                return
            if scenario == "recover_after_disconnect":
                with self.server.counter_lock:
                    key = request.get("run_case_id", request.get("request_id"))
                    attempt = self.server.counters.get(key, 0) + 1
                    self.server.counters[key] = attempt
                if attempt == 1:
                    return
            if scenario == "malformed":
                self.wfile.write(b"not-json\n")
                return
            if scenario == "oversized":
                self.wfile.write(b"x" * (MAX_FRAME_BYTES + 1) + b"\n")
                return
            response = {
                "protocol": PROTOCOL,
                "request_id": request["request_id"],
                "device_id": "LAB-SIM-001",
                "firmware": "simulator/0.1.0",
                "status": "ready",
                "temperature_c": 34.5,
                "supply_voltage_v": 12.0,
            }
            if scenario == "missing_field":
                del response["temperature_c"]
            elif scenario == "wrong_type":
                response["temperature_c"] = True
            elif scenario == "out_of_range":
                response["supply_voltage_v"] = 120
            elif scenario == "wrong_id":
                response["request_id"] = "wrong-request"
            frame = encode_frame(response)
            self.wfile.write(frame.rstrip(b"\n") if scenario == "no_newline" else frame)
        except (ValueError, KeyError, OSError, socket.timeout):
            # Malformed client frames and clients closing on timeout are expected.
            return


class SimulatorServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, address):
        super().__init__(address, SimulatorHandler)
        self.counter_lock = threading.Lock()
        self.counters = {}


@contextmanager
def running_simulator(host="127.0.0.1", port=0):
    server = SimulatorServer((host, port))
    worker = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
    worker.start()
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=3)
