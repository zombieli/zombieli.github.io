"""Small, documented JSON-lines protocol and strict response validation."""

import json
import math

PROTOCOL = "diagnostics-sim/1"
MAX_FRAME_BYTES = 16384
ERROR_CODES = frozenset({"timeout", "connection_error", "protocol_error", "validation_error"})
SCENARIOS = (
    "normal", "timeout", "disconnect", "malformed", "missing_field",
    "wrong_type", "out_of_range", "wrong_id", "oversized", "no_newline",
    "recover_after_disconnect",
)


class DiagnosticError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def encode_frame(value: dict) -> bytes:
    return (json.dumps(value, allow_nan=False, separators=(",", ":")) + "\n").encode("utf-8")


def decode_frame(frame: bytes) -> dict:
    try:
        value = json.loads(frame.decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    except (ValueError, UnicodeDecodeError) as exc:
        raise DiagnosticError("protocol_error", "Response is not valid UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise DiagnosticError("protocol_error", "Response must be a JSON object")
    return value


def validate_status(value: dict, request_id: str) -> dict:
    if value.get("protocol") != PROTOCOL or value.get("request_id") != request_id:
        raise DiagnosticError("validation_error", "Protocol or request identifier does not match")
    for field in ("device_id", "firmware", "status"):
        if not isinstance(value.get(field), str) or not value[field].strip():
            raise DiagnosticError("validation_error", f"{field} must be a non-empty string")
    if value["status"] not in {"ready", "busy", "fault"}:
        raise DiagnosticError("validation_error", "Unknown device status")
    # Lab protocol bounds, not a product's certified operating envelope.
    for field, minimum, maximum in (("temperature_c", -50, 150), ("supply_voltage_v", 0, 60)):
        number = value.get(field)
        if type(number) not in (int, float) or not math.isfinite(number):
            raise DiagnosticError("validation_error", f"{field} must be a finite number")
        if not minimum <= number <= maximum:
            raise DiagnosticError("validation_error", f"{field} is outside lab protocol bounds")
    return value
