"""Validate configuration before opening a connection or producing reports."""

import math

from .protocol import ERROR_CODES, SCENARIOS


def validate_config(config: dict) -> dict:
    def require(condition, message):
        if not condition:
            raise ValueError(message)

    require(isinstance(config, dict), "Configuration must be an object")
    require(set(config) == {"schema_version", "target", "timeout_s", "max_attempts", "cases"},
            "Unexpected or missing configuration fields")
    require(type(config["schema_version"]) is int and config["schema_version"] == 1, "Unsupported schema_version")
    target = config["target"]
    require(isinstance(target, dict) and set(target) == {"host", "port"}, "target requires host and port")
    # Version 0.1 deliberately addresses a local lab, not arbitrary network hosts.
    require(target["host"] == "127.0.0.1", "Version 0.1 requires host 127.0.0.1")
    require(type(target["port"]) is int and 1 <= target["port"] <= 65535, "Invalid target port")
    require(type(config["timeout_s"]) in (int, float) and math.isfinite(config["timeout_s"])
            and 0.005 <= config["timeout_s"] <= 60, "timeout_s must be between 0.005 and 60")
    require(type(config["max_attempts"]) is int and 1 <= config["max_attempts"] <= 5,
            "max_attempts must be 1 to 5 (including the first attempt)")
    require(isinstance(config["cases"], list) and 1 <= len(config["cases"]) <= 100,
            "Provide 1 to 100 cases")
    seen = set()
    for case in config["cases"]:
        require(isinstance(case, dict), "Each case must be an object")
        require(set(case) == {"case_id", "requirement_id", "scenario", "expected_error"},
                "Unexpected or missing case fields")
        for field in ("case_id", "requirement_id"):
            require(isinstance(case[field], str) and 0 < len(case[field]) <= 100, f"Invalid {field}")
        require(case["case_id"] not in seen, "Duplicate case_id")
        seen.add(case["case_id"])
        require(isinstance(case["scenario"], str) and case["scenario"] in SCENARIOS, "Unknown scenario")
        require(case["expected_error"] is None or
                (isinstance(case["expected_error"], str) and case["expected_error"] in ERROR_CODES),
                "Unknown expected_error")
    return config


def demo_config(port: int, unexpected_failure=False) -> dict:
    scenarios = [
        ("normal", None, "P1-R02"),
        ("timeout", "timeout", "P1-R03"),
        ("disconnect", "connection_error", "P1-R01"),
        ("malformed", "protocol_error", "P1-R02"),
        ("missing_field", "validation_error", "P1-R02"),
        ("wrong_type", "validation_error", "P1-R02"),
        ("out_of_range", "validation_error", "P1-R02"),
        ("wrong_id", "validation_error", "P1-R02"),
        ("oversized", "protocol_error", "P1-R02"),
        ("no_newline", "protocol_error", "P1-R02"),
        ("recover_after_disconnect", None, "P1-R03"),
    ]
    result = {
        "schema_version": 1,
        "target": {"host": "127.0.0.1", "port": port},
        "timeout_s": 0.15,
        "max_attempts": 2,
        "cases": [dict(case_id=f"CASE-{index:02d}", requirement_id=req, scenario=scenario, expected_error=expected)
                  for index, (scenario, expected, req) in enumerate(scenarios, 1)],
    }
    if unexpected_failure:
        result["cases"][4]["expected_error"] = None
    return result
