# Device Diagnostics Lab

A local TCP simulator and Python diagnostics runner for exploring device communication, failure handling and repeatable testing. The simulator returns synthetic status readings and deliberately injects faults. No physical hardware has been connected or validated in this version.

This is a personal portfolio project. The development log records implementation and verification steps. It is not a product from Motium or another employer.

## Run the demo

Requires Python 3.11 or later. The application uses only the Python standard library.

```sh
python -m device_diagnostics demo --output reports
```

The command launches a local TCP server on an automatically selected port, runs 11 scenarios and saves a unique report directory. Nine scenarios deliberately return diagnostic faults; the test suite should pass when these faults are correctly identified. A passing test is not a claim that a device is healthy.

Show how an unexpected defect fails the suite:

```sh
python -m device_diagnostics demo --unexpected-failure --output reports
```

Exit codes: `0` means expectations matched; `1` means test failure or internal runner error; `2` means configuration or report-writing failure; `130` means interrupted. The unexpected-failure demo should return `1`.

## Run separate processes

Terminal one:

```sh
python -m device_diagnostics serve --port 8765
```

Terminal two:

```sh
python -m device_diagnostics run --config examples/local-suite.json --output reports
```

Stop the server with Ctrl+C. Version 0.1 binds and connects to IPv4 loopback only. A real-device adapter is a future extension, not an implemented feature.

## Test

```sh
python -m venv .venv
# Windows: .venv\Scripts\python.exe
# macOS/Linux: .venv/bin/python
python -m pip install -r requirements-dev.txt
python -m pytest
```

Run the install and test commands with the virtual environment's Python after activating it or using its full path. Integration tests start actual local TCP servers, not just function mocks. They cover framing, malformed and oversized messages, disconnects, deadlines, finite retries, recovery, configuration rejection, reporting and CLI exit codes.

## Evidence

Each run creates `report.json`, `cases.csv` and `events.jsonl`. The report records Python/platform information, a hash of the Python source files, the exact configuration, expected and observed outcomes, and every connection attempt. Reports are staged and then renamed so incomplete writes are not presented as completed runs. A failed write may leave an `_pending-` directory for investigation.

Reviewed sample output and test results are saved under `evidence/` when generated. They are actual runs against the simulator. Default generated reports and the local virtual environment are excluded from version control.

## Architecture and decisions

```text
JSON configuration → Runner → TCP adapter → Local simulator
                       ↓
                  expectation checks
                       ↓
               JSON + CSV + attempt log
```

- A documented JSON-lines protocol makes frames and failures easy to inspect.
- The TCP adapter has a per-attempt deadline and a 16 KiB response limit.
- Only transport failures are retried. Malformed or semantically invalid responses fail immediately.
- Test outcomes and diagnostic faults are separate fields, so an expected timeout can be correctly detected without reporting a healthy device.
- Each suite gets a unique identifier, keeping retry recovery state independent between runs.

See [protocol and requirements](docs/protocol-and-requirements.md), [development log](docs/development-log.md) and [case study](docs/case-study.md).

## Limitations

The readings, lab bounds and fault scenarios are synthetic. No serial protocol, MQTT, environmental testing, firmware or production device certification is implemented. The simulator's scenario field is a test control, not a real industrial device command. Tests use local TCP; timing varies by machine and is not an industrial performance benchmark. This version does not cover every possible network fault or operating system.

## Repository and portfolio

Intended GitHub owner: [zombieli](https://github.com/zombieli). The project has not yet been published; the final repository and portfolio links will be added after deployment is verified.
