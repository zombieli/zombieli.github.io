import copy
import csv
import json
import subprocess
import sys
from pathlib import Path

import pytest

from device_diagnostics.cli import main
from device_diagnostics.config import demo_config, validate_config
from device_diagnostics.protocol import DiagnosticError, decode_frame, validate_status
from device_diagnostics.reporting import write_report
from device_diagnostics.runner import execute
from device_diagnostics.simulator import running_simulator


@pytest.fixture
def lab():
    with running_simulator() as server:
        yield demo_config(server.server_address[1])


def test_fault_suite_over_real_tcp(lab):
    report = execute(lab)
    assert report["summary"] == {"pass": 11, "fail": 0, "error": 0, "skipped": 0, "total": 11, "diagnostic_faults": 9}
    assert report["evidence_origin"] == "simulator"
    cases = {c["scenario"]: c for c in report["cases"]}
    assert cases["normal"]["actual"]["device_id"] == "LAB-SIM-001"
    assert cases["timeout"]["attempt_count"] == 2
    assert cases["malformed"]["attempt_count"] == 1  # Do not retry a bad protocol frame.
    recovery = cases["recover_after_disconnect"]
    assert [a["diagnostic"] for a in recovery["attempts"]] == ["connection_error", "ok"]
    assert recovery["outcome"] == "pass"
    assert report["source_sha256"] and len(report["source_sha256"]) == 64


def test_recovery_state_does_not_leak_between_runs(lab):
    lab["cases"] = [lab["cases"][-1]]
    one, two = execute(lab), execute(lab)
    assert one["run_id"] != two["run_id"]
    assert one["cases"][0]["attempt_count"] == two["cases"][0]["attempt_count"] == 2


def test_unexpected_fault_is_failure_not_success(lab):
    lab["cases"] = [lab["cases"][4]]
    lab["cases"][0]["expected_error"] = None
    result = execute(lab)
    assert result["summary"]["fail"] == 1
    assert result["cases"][0]["diagnostic"] == "validation_error"
    assert "temperature_c" not in result["cases"][0]["attempts"][0]["response"]


def test_expected_fault_missing_is_failure(lab):
    lab["cases"] = [lab["cases"][0]]
    lab["cases"][0]["expected_error"] = "timeout"
    result = execute(lab)
    assert result["summary"]["fail"] == 1
    assert result["cases"][0]["diagnostic"] == "ok"


def test_unavailable_endpoint_fails_with_bounded_attempts():
    with running_simulator() as server:
        port = server.server_address[1]
    config = demo_config(port)
    config["cases"] = [config["cases"][0]]
    report = execute(config)
    assert report["summary"]["fail"] == 1
    assert report["cases"][0]["diagnostic"] in {"connection_error", "timeout"}
    assert report["cases"][0]["attempt_count"] == 2


def test_adapter_bug_is_reported_as_error(lab):
    class BrokenAdapter:
        def request(self, payload, timeout_s):
            raise RuntimeError("intentional test bug")
    lab["cases"] = [lab["cases"][0]]
    report = execute(lab, BrokenAdapter())
    assert report["summary"]["error"] == 1
    assert report["cases"][0]["diagnostic"] == "internal_error"
    assert report["cases"][0]["attempt_count"] == 1


@pytest.mark.parametrize("field,value", [
    ("timeout_s", 0), ("timeout_s", -1), ("timeout_s", True),
    ("timeout_s", float("nan")), ("timeout_s", float("inf")),
    ("max_attempts", 0), ("max_attempts", 6), ("max_attempts", 1.5),
    ("max_attempts", True), ("schema_version", 2), ("schema_version", True),
    ("cases", []), ("cases", {}),
])
def test_bad_configuration_rejected(field, value):
    config = demo_config(8765)
    config[field] = value
    with pytest.raises(ValueError):
        validate_config(config)


@pytest.mark.parametrize("target", [{"host": "example.com", "port": 8765},
                                    {"host": "127.0.0.1", "port": 0},
                                    {"host": "127.0.0.1", "port": True},
                                    {"host": "127.0.0.1", "port": 65536}, {}])
def test_bad_targets_rejected(target):
    config = demo_config(8765)
    config["target"] = target
    with pytest.raises(ValueError):
        validate_config(config)


def test_duplicate_and_unknown_cases_rejected():
    config = demo_config(8765)
    config["cases"].append(copy.deepcopy(config["cases"][0]))
    with pytest.raises(ValueError, match="Duplicate"):
        validate_config(config)
    for key, value in [("scenario", "not_a_scenario"), ("expected_error", "typographical_error")]:
        config = demo_config(8765)
        config["cases"][0][key] = value
        with pytest.raises(ValueError):
            validate_config(config)


@pytest.mark.parametrize("frame", [b"[]", b"null", b"42", b"{", b'\xff', b'{"x": NaN}'])
def test_bad_json_responses(frame):
    with pytest.raises(DiagnosticError) as err:
        decode_frame(frame)
    assert err.value.code == "protocol_error"


@pytest.mark.parametrize("value", [True, "12", None, float("nan"), float("inf"), -51, 151])
def test_temperature_validation_rejects_invalid_numbers(value):
    response = dict(protocol="diagnostics-sim/1", request_id="r1", device_id="a", firmware="0.1",
                    status="ready", temperature_c=value, supply_voltage_v=12)
    with pytest.raises(DiagnosticError):
        validate_status(response, "r1")


def test_reports_match_and_preserve_raw_events(lab, tmp_path):
    report = execute(lab)
    folder = write_report(report, tmp_path)
    saved = json.loads((folder / "report.json").read_text(encoding="utf-8"))
    assert saved == report
    with (folder / "cases.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == len(report["cases"])
    events = [json.loads(line) for line in (folder / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(events) == sum(c["attempt_count"] for c in report["cases"])
    assert all(e["run_id"] == report["run_id"] for e in events)
    assert not list(tmp_path.glob("_pending-*"))
    with pytest.raises(FileExistsError):
        write_report(report, tmp_path)


def test_report_destination_error_is_not_hidden(lab, tmp_path):
    output = tmp_path / "a-file"
    output.write_text("not a directory", encoding="utf-8")
    lab["cases"] = [lab["cases"][0]]
    with pytest.raises(OSError):
        write_report(execute(lab), output)


@pytest.mark.parametrize("extra,expected", [([], 0), (["--unexpected-failure"], 1)])
def test_cli_exit_codes_and_reports(tmp_path, extra, expected):
    result = subprocess.run([sys.executable, "-m", "device_diagnostics", "demo", "--output", str(tmp_path), *extra],
                            capture_output=True, text=True, timeout=20)
    assert result.returncode == expected, result.stdout + result.stderr
    assert "Evidence origin: simulator" in result.stdout
    assert len(list(tmp_path.glob("*/report.json"))) == 1


def test_cli_invalid_config_and_output_error(tmp_path):
    invalid = tmp_path / "config.json"
    invalid.write_text("{}", encoding="utf-8")
    assert main(["run", "--config", str(invalid), "--output", str(tmp_path / "reports")]) == 2
    assert not (tmp_path / "reports").exists()
    file = tmp_path / "a-file"
    file.write_text("exists", encoding="utf-8")
    assert main(["demo", "--output", str(file)]) == 2


def test_cli_two_process_style_configuration(lab, tmp_path):
    config = tmp_path / "local.json"
    config.write_text(json.dumps(lab), encoding="utf-8")
    assert main(["run", "--config", str(config), "--output", str(tmp_path / "reports")]) == 0
