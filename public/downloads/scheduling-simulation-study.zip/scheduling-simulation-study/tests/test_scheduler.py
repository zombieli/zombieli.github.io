import pytest
from scheduler import Job, metrics, scenarios, schedule, violations


def test_known_policies():
    jobs=[Job('a',0,8),Job('b',0,2),Job('c',0,4)]
    assert [s['job_id'] for s in schedule(jobs,'fcfs')]==['a','b','c']
    result=schedule(jobs,'spt')
    assert result==[{'job_id':'b','start':0,'end':2},{'job_id':'c','start':4,'end':8},{'job_id':'a','start':10,'end':18}]
    assert metrics(jobs,result)['mean_wait_min']==14/3


@pytest.mark.parametrize('case',list(scenarios()),ids=lambda case:case['name'])
def test_generated_schedules_are_feasible_and_repeatable(case):
    jobs=[Job(**j) for j in case['jobs']]
    for policy in ['fcfs','spt']:
        result=schedule(jobs,policy)
        assert violations(jobs,result)==[]
        assert result==schedule(jobs,policy)


def test_sparse_and_empty_inputs():
    assert schedule([])==[]
    assert metrics([],[])['mean_wait_min']==0
    assert schedule([Job('a',20,5),Job('b',100,5)])[-1]['start']==100


@pytest.mark.parametrize('jobs',[ [Job('a',0,0)], [Job('a',-1,2)], [Job('a',0,True)], [Job('a',0,1),Job('a',2,1)], [Job('',0,2)] ])
def test_invalid_jobs_rejected(jobs):
    with pytest.raises(ValueError):schedule(jobs)


@pytest.mark.parametrize('slots,expected',[
    ([{'job_id':'a','start':-1,'end':3}], 'before_release'),
    ([{'job_id':'a','start':0,'end':3}], 'wrong_duration'),
    ([{'job_id':'a','start':0,'end':4},{'job_id':'a','start':6,'end':10}], 'duplicate_job'),
    ([{'job_id':'other','start':0,'end':4}], 'unknown_job'),
    ([], 'missing_jobs'),
    ([{'job_id':'a','start':False,'end':4}], 'invalid_time'),
])
def test_independent_validator_rejects_corrupt_schedules(slots,expected):
    jobs=[Job('a',0,4)]
    assert expected in violations(jobs,slots)
    with pytest.raises(ValueError):metrics(jobs,slots)


def test_gap_violation_and_starvation_tradeoff():
    jobs=[Job('a',0,4),Job('b',0,2)]
    assert 'overlap_or_missing_gap' in violations(jobs,[{'job_id':'a','start':0,'end':4},{'job_id':'b','start':5,'end':7}])
    case=next(c for c in scenarios() if c['name']=='steady-short-arrivals')
    jobs=[Job(**j) for j in case['jobs']]
    fcfs=metrics(jobs,schedule(jobs,'fcfs'))
    spt=metrics(jobs,schedule(jobs,'spt'))
    assert spt['mean_wait_min']<fcfs['mean_wait_min']
    assert spt['max_wait_min']>fcfs['max_wait_min']
