import csv
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter_ns
from statistics import median

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from scheduler import Job, metrics, scenarios, schedule

ROOT = Path(__file__).resolve().parent


def run(output=ROOT / 'results'):
    output.mkdir(parents=True, exist_ok=True)
    inputs = list(scenarios())
    rows, timelines = [], []
    for case in inputs:
        jobs = [Job(**job) for job in case['jobs']]
        for policy in ['fcfs', 'spt']:
            timings = []
            for _ in range(50):
                start = perf_counter_ns()
                timeline = schedule(jobs, policy, gap=2)
                timings.append((perf_counter_ns() - start) / 1_000_000)
            result = {'scenario': case['name'], 'policy': policy, 'job_count': len(jobs), **metrics(jobs, timeline), 'median_compute_ms': median(timings)}
            rows.append(result)
            timelines.append({'scenario':case['name'], 'policy':policy, 'slots':timeline})
    summary = {'executed_at_utc':datetime.now(timezone.utc).isoformat(), 'environment':{'python':platform.python_version(),'platform':platform.system(),'matplotlib':matplotlib.__version__}, 'source_sha256':hashlib.sha256(b''.join(p.read_bytes() for p in [ROOT/'scheduler.py',ROOT/'experiment.py'])).hexdigest(), 'data_origin':'synthetic', 'gap_minutes':2, 'timing_repetitions':50, 'scenario_count':len(inputs), 'rows':rows}
    for filename, content in [('inputs.json',inputs),('timelines.json',timelines),('results.json',summary)]:
        (output/filename).write_text(json.dumps(content,indent=2)+'\n',encoding='utf-8')
    with (output/'results.csv').open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
    fig, axes = plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for ax, metric, title in [(axes[0],'mean_wait_min','Average waiting time'),(axes[1],'max_wait_min','Longest waiting time')]:
        baseline=[r[metric] for r in rows if r['policy']=='fcfs']
        candidate=[r[metric] for r in rows if r['policy']=='spt']
        top=max(baseline+candidate)*1.08
        ax.plot([0,top],[0,top],color='#91a2b5',linestyle='--',label='Equal result')
        ax.scatter(baseline[:20],candidate[:20],color='#1d4ed8',s=32,label='20 mixed-arrival seeds')
        ax.scatter(baseline[20],candidate[20],color='#b75532',marker='D',s=58,label='Steady short arrivals')
        ax.scatter(baseline[21],candidate[21],color='#24836c',marker='s',s=45,label='Sparse arrivals')
        ax.set(title=title,xlabel='FCFS waiting time (minutes)',ylabel='SPT waiting time (minutes)',xlim=(-4,top),ylim=(-4,top))
        ax.grid(alpha=.15);ax.set_axisbelow(True)
    axes[0].legend(loc='upper left',fontsize=8)
    fig.suptitle('Synthetic single-bench scheduling • 22 scenarios • 2-minute changeover',fontsize=14)
    fig.savefig(output/'waiting-time-comparison.png',dpi=160)
    fig.savefig(output/'waiting-time-comparison.svg')
    plt.close(fig)
    print(f'{len(rows)} feasible policy runs across {len(inputs)} scenarios; zero constraint violations')
    stress=[r for r in rows if r['scenario']=='steady-short-arrivals']
    print(json.dumps(stress,indent=2))


if __name__=='__main__':
    run()
