"""Deterministic single-bench dispatch policies using synthetic jobs."""
from dataclasses import asdict, dataclass
import random


@dataclass(frozen=True)
class Job:
    id: str
    release: int
    duration: int


def validate_jobs(jobs, gap):
    if type(gap) is not int or gap < 0:
        raise ValueError('Gap must be a non-negative integer')
    ids = set()
    for job in jobs:
        if not isinstance(job.id, str) or not job.id.strip() or job.id in ids:
            raise ValueError('Job IDs must be nonempty and unique')
        if type(job.release) is not int or job.release < 0 or type(job.duration) is not int or job.duration <= 0:
            raise ValueError('Release and duration must be valid integer minutes')
        ids.add(job.id)


def schedule(jobs, policy='fcfs', gap=2):
    jobs = list(jobs)
    validate_jobs(jobs, gap)
    if policy not in ('fcfs', 'spt'):
        raise ValueError('Unknown dispatch policy')
    pending, clock, timeline = jobs[:], 0, []
    while pending:
        available = [job for job in pending if job.release <= clock]
        if not available:
            clock = min(job.release for job in pending)
            available = [job for job in pending if job.release <= clock]
        key = (lambda job: (job.release, job.id)) if policy == 'fcfs' else (lambda job: (job.duration, job.release, job.id))
        job = min(available, key=key)
        timeline.append({'job_id': job.id, 'start': clock, 'end': clock + job.duration})
        clock += job.duration + gap
        pending.remove(job)
    return timeline


def violations(jobs, timeline, gap=2):
    """Independent feasibility check; does not call the dispatch implementation."""
    validate_jobs(jobs, gap)
    lookup = {job.id: job for job in jobs}
    problems, seen, previous_end = [], set(), None
    for slot in timeline:
        job_id, start, end = slot.get('job_id'), slot.get('start'), slot.get('end')
        if job_id not in lookup:
            problems.append('unknown_job')
            continue
        if job_id in seen:
            problems.append('duplicate_job')
        seen.add(job_id)
        job = lookup[job_id]
        if type(start) is not int or type(end) is not int:
            problems.append('invalid_time')
            continue
        if start < job.release:
            problems.append('before_release')
        if end - start != job.duration:
            problems.append('wrong_duration')
        if previous_end is not None and start < previous_end + gap:
            problems.append('overlap_or_missing_gap')
        previous_end = end
    if seen != set(lookup):
        problems.append('missing_jobs')
    return problems


def metrics(jobs, timeline, gap=2):
    errors = violations(jobs, timeline, gap)
    if errors:
        raise ValueError('Infeasible schedule: ' + ', '.join(errors))
    release = {job.id: job.release for job in jobs}
    waits = [slot['start'] - release[slot['job_id']] for slot in timeline]
    return {'mean_wait_min': sum(waits) / len(waits) if waits else 0, 'max_wait_min': max(waits, default=0), 'finish_min': timeline[-1]['end'] if timeline else 0, 'constraint_violations': 0}


def scenarios():
    for seed in range(20):
        rng = random.Random(seed)
        jobs = [Job(f'J{i:03}', rng.randrange(121), rng.randrange(2,26)) for i in range(30)]
        yield {'name': f'mixed-{seed:02}', 'seed': seed, 'jobs': [asdict(j) for j in jobs]}
    yield {'name': 'steady-short-arrivals', 'seed': None, 'jobs': [asdict(Job('long-job',0,25))] + [asdict(Job(f'short-{i:02}',i*3,1)) for i in range(31)]}
    yield {'name': 'sparse-arrivals', 'seed': None, 'jobs': [asdict(Job(f'J{i:03}',i*40,10)) for i in range(12)]}
